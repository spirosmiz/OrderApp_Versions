require = require("esm")(module); // Enable ES module loading

// Import your ES module (start-dev.mjs)
const { exec } = require("./start-dev.js");

// Execute your command
exec("npm run dev", (error, stdout, stderr) => {
  if (error) {
    console.error(`Error: ${error}`);
    return;
  }
  console.log(stdout);
  console.error(stderr);
});
module.exports = {
  exec,
};
