import { useEffect, useState } from "react";
import Table, { TableProps } from "./components/tables";
import "./index.css";
import "./sass/bootstrap.scss";
import "./sass/font-awesome.scss";
import axios from "axios";
import { motion } from "framer-motion";
import "./assets/table.png";
import tableImage from "./assets/table.png";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";
import { useAlert } from "./components/Modals/alert"; // Import the useAlert hook

export type propTables = {
  position: string;
  onclickState: (position: string) => void;
  onclickSwitch: (position: string) => void;
};
const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
function App() {
  const [server_error, setServerError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { position } = useParams();
  const [showOrder, setShowOrder] = useState(false);
  const [showTable, setShowTable] = useState(true);
  const [table_index, setTable] = useState("");
  const [tablesList, setTableList] = useState<TableProps[]>([]);

  const { showAlert } = useAlert(); // Use the alert from the context

  useEffect(() => {
    // Fetch data from the server and map the availability of tables
    async function fetchData() {
      try {
        console.log(position, "here is the position ");
        const response = await axios.post(
          `${localhost}:3001/availabilities/${position}`
        );
        setTableList(response.data);
      } catch (error: unknown) {
        if (axios.isAxiosError(error)) {
          // Το error είναι τύπου AxiosError
          if (error.response) {
            console.log(error.response.data);
            showAlert(error.response.data || "Σφάλμα από τον server");
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        } else {
          showAlert("Άγνωστο σφάλμα.");
        }

        console.error(error);
      }
    }

    fetchData();
  }, [position]);

  function handleOrder1(id: string, status: string) {
    console.log(id + "here is the pressed table and the status " + status);
    if (status === "available") {
      setShowTable(false);
      setTable(id);
      navigate(`/app/order/${id}`);
    }
  }

  function nextLevel(id: string) {
    setShowOrder(true);
    setShowTable(false);
    setTable(id);
    console.log(id);
    console.log(table_index);
    navigate(`/app/order/${id}`);
  }

  function handlePayment(id: string) {
    // console.log("The id is " + id);
    navigate(`/app/${position}/${id}`);
  }

  function handleView(id: string) {
    //console.log("The id is " + id);
    navigate(`/app/view/${position}/${id}`);
  }
  function handleCatalog() {
    console.log("hello");
    navigate(`/app/view/${position}/${table_index}`);
  }
  return (
    <>
      <div className="ps-1 pe-1">
        <div>
          <motion.button
            className="edit-menu-button rounded border mt-2 border-dark bg-white text-dark ms-2 mt-1"
            style={{ display: showTable ? "block" : "none" }}
            onClick={() => {
              navigate("/");
            }}
          >
            <i className="fa-solid fa-arrow-left"></i>
            &nbsp;Back
          </motion.button>
          <div style={{ display: showTable ? "flex" : "none" }}>
            <div className="row mt-5">
              {tablesList.length > 0 &&
                tablesList.map((table) => (
                  <div className="col-3" key={table.id}>
                    <Table
                      key={table.id}
                      status={table.status}
                      id={table.id}
                      onClickOrder={handleOrder1}
                      onClickPay={() => handlePayment(table.id)}
                      onclickView={() => handleView(table.id)}
                      onClickAddOrder={nextLevel}
                      img={{
                        src: tableImage,
                        alt: "Description of the image",
                      }}
                    />
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
