// index.tsx
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import MainMenu from "./Main_Menu";
import Catalog from "./components/catalog";
import App from "./App";
import Layout from "./Layout";
import "./index.css";
import "./sass/bootstrap.scss";
import Payment from "./components/payment";
import { AlertProvider } from "./components/Modals/alert";
import Order_View from "./components/view_order";
import Login from "./Login";
import DashBoard from "./components/dashboard";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <main
    style={{
      overflowY: "scroll",
      height: "100%",
      overflowX: "hidden",
      fontFamily: "'Helvetica', serif",
    }}
  >
    <AlertProvider>
      <Router>
        <Layout />
        <Routes>
          <Route path="/login" index element={<Login />} />
          <Route path="/" index element={<MainMenu />} />
          <Route path="/edit" index element={<DashBoard />} />
          <Route path="app/:position" element={<App />} />
          <Route path="app/order/:table" element={<Catalog />} />
          <Route path="app/:position/:table" element={<Payment />} />
          <Route path="app/view/:position/:table" element={<Order_View />} />
        </Routes>
      </Router>
    </AlertProvider>
  </main>
);
