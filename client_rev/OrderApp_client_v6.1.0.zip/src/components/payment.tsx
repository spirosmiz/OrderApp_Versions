import { useNavigate, useParams } from "react-router-dom";
import { Button } from "react-bootstrap";
import { useEffect, useState } from "react";
import axios from "axios";
import Order_Tab from "./tabs";
import Payment_Products from "./payment_products";
import Modal_Comp from "./Modals/modal";
import { useAlert } from "./Modals/alert";
const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
function Payment() {
  const { table } = useParams();
  const [order, setOrder] = useState<{ [key: string]: any[] }>({});
  const [selectedTab, setSelectedTab] = useState<string>("");
  const [tabs, setTabs] = useState<string[]>([]);
  const [indexTab, setIndexTab] = useState<number>(1);
  const [selectedValues, setSelectedValues] = useState<{
    [key: string]: boolean[];
  }>({});
  // Track selected products by their ids
  const [view, setSelectedView] = useState<any[]>([]); // the content of the view
  const { showAlert } = useAlert();
  useEffect(() => {
    async function fetchData() {
      try {
        let response = await axios.post(`${localhost}:3001/viewOrder/${table}`);
        if (response.status !== 200) {
          console.log("hellooo");
          showAlert(response.data.msg);
        } else {
          if (
            response.data === "Error retrieving specified order : undefined"
          ) {
            window.history.back();
          } else {
            setOrder(response.data);
          }
          const newTabs = Object.keys(response.data);
          setTabs(newTabs);
          const firstKey = Object.keys(response.data)[0];
          setSelectedView(response.data[firstKey]);
          setSelectedTab(newTabs[0]);
          const initialSelectedValues = Object.fromEntries(
            newTabs.map((tab) => [
              tab,
              Array(response.data[tab].length).fill(false),
            ])
          );
          setSelectedValues(initialSelectedValues);
        }
      } catch (error) {
        if (axios.isAxiosError(error)) {
          // Το error είναι τύπου AxiosError
          if (error.response) {
            console.log("hellooo 1");
            console.log(error.response.data);
            window.history.back();
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        } else {
          showAlert("Άγνωστο σφάλμα.");
        }
      }
    }

    fetchData();
  }, [table]);

  function handleTab(id: string) {
    setSelectedView(order[id]);
    setSelectedTab(id);
    const index = tabs.indexOf(id);
    setIndexTab(index);
    console.log(index);
  }
  let [allFalse, setAllFalse] = useState(true); //συνθήκη για το αν έχει επιλεχθεί η όχι
  function handleSelectedProduct(index: number) {
    const updatedSelectedValues = { ...selectedValues };
    updatedSelectedValues[selectedTab][index] =
      !updatedSelectedValues[selectedTab][index]; // Toggle selection
    setSelectedValues(updatedSelectedValues);
    console.log(updatedSelectedValues + "hello");
    setAllFalse(
      Object.values(selectedValues).every((array) =>
        array.every((value) => value === false)
      )
    );
  }

  const [modalShow, setModalShow] = useState(false); //usestate for the visibillity of modal
  const [grossValue, setGrossValue] = useState<number>(0);
  const [payWay, setPayWay] = useState<number>(0);
  const [payData, setPayData] = useState({});
  function handleModal(id: number) {
    console.log(id);
    if (id === 3) {
      setPayWay(3);
      axios
        .post(`${localhost}:3001/prepaySum/${table}`)

        .then((response) => {
          const sum = response.data.toFixed(2);
          setGrossValue(sum);
        })
        .catch((error) => {
          if (error.response) {
            console.log(error.response.data);
            showAlert(error.response.data || "Σφάλμα από τον server");
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        });
    } else if (id === 2) {
      setPayWay(2);
      console.log(selectedTab);
      let my_key = selectedTab;
      let data = {
        [my_key]: [],
      };
      console.log(data + "here is the data to pay");
      axios
        .post(`${localhost}:3001/prepaySum/${table}`, data)

        .then((response) => {
          const sum = response.data;
          setGrossValue(sum);
        })
        .catch((error) => {
          if (error.response) {
            console.log(error.response.data);
            showAlert(error.response.data || "Σφάλμα από τον server");
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        });
      setPayData(data);
    } else if (id === 1) {
      setPayWay(1);
      let data1: { [key: string]: number[] } = {};
      Object.entries(selectedValues).forEach(([key, valueArray]) => {
        let add_key = false;
        const trueIndices = [] as any;
        valueArray.forEach((item, index) => {
          if (item === true) {
            add_key = true;
            trueIndices.push(index);
          }
          if (add_key === true) {
            data1[key] = trueIndices;
          }
        });
        console.log(trueIndices + "the true indicates");

        setPayData(data1);
      });
      console.log(data1);
      axios
        .post(`${localhost}:3001/prepaySum/${table}`, data1)
        .then((response) => {
          const sum = response.data.toFixed(2);
          setGrossValue(sum);
        })
        .catch((error) => {
          if (error.response) {
            console.log(error.response.data);
            showAlert(error.response.data || "Σφάλμα από τον server");
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        });
    }

    setModalShow(true);
  }
  return (
    <>
      <Modal_Comp
        isVisible={modalShow}
        onClose={() => setModalShow(false)}
        total={grossValue}
        table={table}
        payWay={payWay}
        dataToPay={payData}
      ></Modal_Comp>
      <div className="row p-0">
        <div
          className="col-12 d-flex border-right border-dark p-0"
          style={{ background: "#222222" }}
        >
          <Order_Tab onClickChooseTab={handleTab} tabs={tabs} />
        </div>
      </div>

      <div className="row p-0 no-gutters">
        <div className="col-9">
          {view.map((item, index) => (
            <Payment_Products
              key={index}
              id={item.id}
              category={item.category}
              price={item.price}
              specifications={item.specifications}
              onclickIdChoose={() => handleSelectedProduct(index)}
              selected={
                selectedValues[selectedTab]
                  ? selectedValues[selectedTab][index]
                  : false
              }
            />
          ))}
        </div>

        <div
          className="col-3 d-flex flex-column gap-5 justify-content-center align-items-center bg-light p-0"
          style={{ minHeight: "100vh" }}
        >
          <Button
            disabled={allFalse}
            className="animation_bnt btn btn-small edit-menu-button border border-dark bg-warning text-white p-3 px-md-5 py-md-3 me-1"
            onClick={() => handleModal(1)}
          >
            <div className="d-flex flex-column text-center p-0">
              <i className="far fa-money-bill-alt fa-2x"></i>
            </div>
          </Button>

          <Button
            className="animation_bnt btn btn-small edit-menu-button border border-dark bg-warning text-white p-3 px-md-5 py-md-3 me-1"
            onClick={() => handleModal(2)}
          >
            <div className="d-flex flex-column text-center p-0">
              <i className="fa fa-list-alt fa-2x"></i>
            </div>
          </Button>
          <Button
            onClick={() => handleModal(3)}
            className="animation_bnt btn btn-small edit-menu-button border border-dark bg-warning text-white p-3 px-md-5 py-md-3 me-1"
          >
            <div className="d-flex flex-column text-center p-0">
              <i className="fa-solid fa-coins fa-2x bg-warning"></i>
            </div>
          </Button>
        </div>
      </div>
    </>
  );
}

export default Payment;
