import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import { useState, ReactNode, useContext, createContext } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

type Modal_Comp_Props = {
  children: ReactNode;
};

const AlertContext = createContext<any>(null);

export const AlertProvider = ({ children }: Modal_Comp_Props) => {
  const [show, setShow] = useState(false);
  const [alertMsg, setAlertMsg] = useState<string | null>(null);

  const showAlert = (msg: string) => {
    setAlertMsg(msg);
    setShow(true);
  };

  const hideAlert = () => {
    setShow(false);
    setAlertMsg(null);
  };

  return (
    <AlertContext.Provider value={{ showAlert, hideAlert }}>
      {children}
      <Modal
        show={show}
        onHide={hideAlert} // Close the modal when clicking outside or using the close button
        centered
        className="modal-header modal-product m-auto text-center"
        animation={true}
      >
        <Modal.Header
          closeButton
          className="d-flex flex-column-reverse justify-content-center align-items-center"
        ></Modal.Header>

        <Modal.Body className="d-flex flex-column text-center">
          {alertMsg && <p>{alertMsg}</p>}
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={hideAlert}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </AlertContext.Provider>
  );
};

// Custom hook to use the AlertContext
export const useAlert = () => {
  return useContext(AlertContext);
};
