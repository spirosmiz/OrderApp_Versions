import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import { useState, ReactNode } from "react";
import "../../index.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

type Modal_Comp_Props = {
  isVisible: boolean;
  onClose: () => void;
  total: number;
  table: ReactNode;
  payWay: number;
  dataToPay: {};
};

export default function Modal_Comp({
  isVisible,
  onClose,
  total,
  table,
  payWay,
  dataToPay,
}: Modal_Comp_Props) {
  const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
  const [paymentType, setPaymentType] = useState<string | null>(null);
  const [showSpinner, setShowSpinner] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<string | null>(null);
  let navigate = useNavigate();

  const handlePaymentSelection = (type: string) => {
    setPaymentType(type); // Set either 'Cash' or 'Card'
  };

  function handleSubmitPayment() {
    setShowSpinner(true);

    // Simulating payment processing
    if (payWay === 3) {
      axios
        .post(`${localhost}:3001/pay/${table}/`)
        .then((response) => {
          if (response.status === 200) {
            setPaymentStatus("Success");
            setTimeout(() => {
              navigate("/");
            }, 1500);
          } else {
            setPaymentStatus("Failure");
          }
          setShowSpinner(false);
        })
        .catch((error) => {
          console.error("There was an error!", error);
          setPaymentStatus("Failure");
          setShowSpinner(false);
        });
    } else if (payWay === 2) {
      axios
        .post(`${localhost}:3001/pay/${table}`, dataToPay)

        .then((response) => {
          if (response.status === 200) {
            setPaymentStatus("Success");
            window.location.reload();
          } else {
            setPaymentStatus("Failure");
          }
          setShowSpinner(false);
        })
        .catch((error) => {
          console.error("There was an error!", error);
          setPaymentStatus("Failure");
          setShowSpinner(false);
        });
      console.log("here is the data to pay in modal");
      console.log(Object.keys(dataToPay) + "here is the data to pay in modal");
    } else if (payWay === 1) {
      console.log(dataToPay);
      axios
        .post(`${localhost}:3001/pay/${table}`, dataToPay)
        .then((response) => {
          if (response.status === 200) {
            setPaymentStatus("Success");
            window.location.reload();
          } else {
            setPaymentStatus("Failure");
          }
          setShowSpinner(false);
        })
        .catch((error) => {
          console.error("There was an error!", error);
          setPaymentStatus("Failure");
          setShowSpinner(false);
        });
      console.log("here is the data to pay in modal");
      console.log(Object.keys(dataToPay) + "here is the data to pay in modal");
    }
  }

  if (paymentType === null) {
    return (
      <Modal
        className="modal-header modal-product m-auto text-center"
        show={isVisible}
        onHide={onClose}
        animation={false}
      >
        <Modal.Header
          closeButton
          className="d-flex flex-column-reverse justify-content-center align-items-center"
        >
          <div>
            <div>Τραπεζι {table}</div>
            <div>Επιλέξτε τρόπο πληρωμής του ποσού {total}€</div>
          </div>
        </Modal.Header>

        <Modal.Body className="d-flex flex-column">
          <Button
            className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
            onClick={() => handlePaymentSelection("Cash")}
          >
            <div className="d-flex flex-column text-center p-0">
              <i className="fa-solid fa-euro-sign fa-2x"></i>
            </div>
          </Button>

          <Button
            className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
            onClick={() => handlePaymentSelection("Card")}
          >
            <div className="d-flex flex-column text-center p-0">
              <i className="fa fa-credit-card fa-2x"></i>
            </div>
          </Button>
        </Modal.Body>
      </Modal>
    );
  }
  // Second, handle the case when a payment type is selected, but no confirmation is done yet
  else if (paymentType != null && paymentStatus == null) {
    return (
      <Modal
        className="modal-header modal-product m-auto text-center"
        show={isVisible}
        onHide={() => setPaymentType(null)}
        animation={false}
      >
        <Modal.Header
          closeButton
          className="d-flex flex-column-reverse justify-content-center align-items-center"
        >
          <div>
            <div>
              Τρόπος πληρωμής <span className="fw-bold"> {paymentType}</span>
            </div>
            <div>Σύνολο {total}€</div>
          </div>
        </Modal.Header>

        <Modal.Body className="d-flex flex-column">
          <Button
            onClick={handleSubmitPayment}
            type="submit"
            variant="primary"
            className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
          >
            {showSpinner ? <i className="fa fa-spinner fa-spin"></i> : "Ναι"}
          </Button>

          <Button
            type="button"
            variant="primary"
            className={`edit-menu-button border border-dark mt-2 mb-2 ${showSpinner ? "disabled" : ""
              }`}
            onClick={() => setPaymentType(null)}
          >
            Όχι
          </Button>
        </Modal.Body>
      </Modal>
    );
  } else {
    return (
      <Modal
        className="modal-header modal-product m-auto text-center"
        show={isVisible}
        onHide={onClose}
        animation={false}
      >
        <Modal.Header
          closeButton
          className="d-flex flex-column-reverse justify-content-center align-items-center"
        >
          <div>
            <div>
              {paymentStatus === "Success"
                ? "Η πληρωμή ολοκληρώθηκε επιτυχώς!"
                : "Η πληρωμή απέτυχε. Προσπαθήστε ξανά."}
            </div>
            <div>Σύνολο {total}€</div>
          </div>
        </Modal.Header>
        <Modal.Body className="d-flex flex-column">
          {paymentStatus === "Success" && payWay != 3 ? (
            <Button
              type="button"
              variant="primary"
              className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
              onClick={onClose}
            >
              Κλείσιμο
            </Button>
          ) : (
            <></>
          )}
        </Modal.Body>
      </Modal>
    );
  }
}
