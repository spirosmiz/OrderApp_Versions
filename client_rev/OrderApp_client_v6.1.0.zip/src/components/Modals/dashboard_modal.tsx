import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import "../../index.css";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

type Modal_Comp_Props = {
  isVisible: boolean;
  onClose: () => void;
  text: string;
  endpoint: string;
};

export default function Dash_Modal({
  isVisible,
  onClose,
  text,
  endpoint,
}: Modal_Comp_Props) {
  const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
  const [showSpinner, setShowSpinner] = useState(false);
  console.log(endpoint);
  function handleAxios() {
    axios
      .post(`${localhost}:3001/${endpoint}`)
      .then((response) => {
        setShowSpinner(false);
      })
      .catch((error) => {
        console.error("There was an error!", error);
        setShowSpinner(false);
      });
  }

  return (
    <Modal
      className="modal-header modal-product m-auto text-center"
      show={isVisible}
      onHide={onClose}
      animation={false}
    >
      <Modal.Header
        closeButton
        className="d-flex flex-column-reverse justify-content-center align-items-center"
      >
        <div className="w-75">{text}</div>
      </Modal.Header>

      <Modal.Body className="d-flex flex-column">
        <Button
          onClick={() => handleAxios()}
          className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
        >
          <div className="d-flex flex-column text-center p-0">Ναι</div>
        </Button>

        <Button
          onClick={onClose}
          className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
        >
          <div className="d-flex flex-column text-center p-0">Όχι</div>
        </Button>
      </Modal.Body>
    </Modal>
  );
}
