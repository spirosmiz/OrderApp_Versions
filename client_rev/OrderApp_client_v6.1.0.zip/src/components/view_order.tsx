import { useNavigate, useParams } from "react-router-dom";
import { Button, Modal, Tabs } from "react-bootstrap";
import { useEffect, useState } from "react";

import axios from "axios";
import Order_Tab from "./tabs";
import Payment_Products from "./payment_products";
import Edit_Comp from "./Modals/edit_modal";
import { viewport } from "@popperjs/core";
import { useAlert } from "./Modals/alert";

const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
function Order_View() {
  const { showAlert } = useAlert();
  const { table } = useParams();
  const [startingOrder, setStartingOrder] = useState<{ [key: string]: any[] }>(
    {}
  );
  const [modified, setmodifiedItem] = useState<{ [key: string]: any[][] }>({});
  const [order, setOrder] = useState<{ [key: string]: any[] }>({});

  const [selectedTab, setSelectedTab] = useState<string>("");
  const [existSpec, setExistSpecs] = useState<string[]>([]);
  const [tabs, setTabs] = useState<string[]>([]);
  const [indexTab, setIndexTab] = useState<number>(1); //the tab we are
  const [deleteItems, setDeleteditems] = useState<{ [key: string]: any[][] }>(
    {}
  );

  const [selectedItem, setSelectedItem] = useState<{
    [key: string]: number;
  }>({});
  const [categoryOptions, setCategoryOptions] = useState<{
    [key: string]: Object[];
  }>({});
  const [category, setCategory] = useState(null);

  const [view, setSelectedView] = useState<any[]>([]); // the content of the view
  const [hasSelectItem, sethasSelectItem] = useState<boolean>(false); //state if you have select an item
  const [showSpecModal, setShowSpecModal] = useState<boolean>(false); //state of modal for the specs of product
  const [startingPrice, setStartingPrice] = useState<number>(0);
  useEffect(() => {
    async function fetchData() {
      try {
        const response = await axios.post(
          `${localhost}:3001/viewOrder/${table}`
        );
        console.log("1233");
        setStartingOrder(JSON.parse(JSON.stringify(response.data)));
        setOrder(response.data);
        const newTabs = Object.keys(response.data);
        setTabs(newTabs);
        const firstKey = Object.keys(response.data)[0];
        setSelectedView(response.data[firstKey]);
        setSelectedTab(newTabs[0]);
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.response) {
            console.log(error.response.data);
            showAlert(error.response.data || "Σφάλμα από τον server");
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        } else {
          showAlert("Άγνωστο σφάλμα.");
        }
      }
    }

    fetchData();
  }, [table]);

  async function discardChanges() {
    try {
      const response = await axios.post(`${localhost}:3001/viewOrder/${table}`);
      setStartingOrder(JSON.parse(JSON.stringify(response.data)));
      setOrder(response.data);
      const newTabs = Object.keys(response.data);
      setTabs(newTabs);
      const firstKey = Object.keys(response.data)[0];
      setSelectedView(response.data[firstKey]);
      setSelectedTab(newTabs[0]);
    } catch (error: unknown) {
      if (axios.isAxiosError(error)) {
        // Το error είναι τύπου AxiosError
        if (error.response) {
          console.log(error.response.data);
          showAlert(error.response.data || "Σφάλμα από τον server");
        } else if (error.request) {
          showAlert(
            "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
          );
        } else {
          showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
        }
      } else {
        showAlert("Άγνωστο σφάλμα.");
      }

      console.error(error);
    }
  }

  function handleTab(id: string) {
    setSelectedItem({});
    sethasSelectItem(false);
    setSelectedView(order[id]);
    setSelectedTab(id);
    const index = tabs.indexOf(id);
    setIndexTab(index);
  }

  function handleSelectedProduct(index: number) {
    if (selectedItem[selectedTab] === index) {
      setSelectedItem({});
      sethasSelectItem(false);
    } else {
      const Item = { [selectedTab]: index };
      setSelectedItem(Item);
      sethasSelectItem(true);
      //console.log(Item);
    }
  }

  const [modalShow, setModalShow] = useState(false); //usestate for the visibillity of modal
  const [editWay, seteditWay] = useState<number>(0);
  const [editData, seteditData] = useState({});
  function handleModal(id: number) {
    console.log(order);
    console.log(startingOrder);
    if (id === 2) {
      seteditWay(2);
      setModalShow(true);
    } else if (id === 1) {
      const startOrder = [] as any;
      const endOrder = [] as any;

      {
        Object.entries(order).map(([key, values]) => {
          Object.entries(values).map(([key, value]) => {
            endOrder.push(value);
          });
        });
      }
      {
        Object.entries(startingOrder).map(([key, values]) => {
          Object.entries(values).map(([key, value]) => {
            startOrder.push(value);
          });
        });
      }
      console.log(startOrder);
      console.log(endOrder);
      const changedItems = [];
      for (let i = 0; i < startOrder.length; i++) {
        if (startOrder[i]["specifications"].length !== 0) {
          if (
            startOrder[i]["specifications"].length ===
            endOrder[i]["specifications"].length
          ) {
            for (let k = 0; k < startOrder[i]["specifications"].length; k++) {
              console.log("hello");
              console.log(startOrder[i]["specifications"][k][0]);
              console.log(endOrder[i]["specifications"].flat());

              if (
                endOrder[i]["specifications"]
                  .flat()
                  .includes(startOrder[i]["specifications"][k][0])
              ) {
                // console.log("it contains");
              } else {
                changedItems.push(startOrder[i]);
                break;
                //  console.log("dosnt contains");
              }
            }
          } else {
            changedItems.push(startOrder[i]);
          }
        }
      }
      console.log("following the changed items");
      console.log(changedItems);
      setmodifiedItem(changedItems as any);
      seteditWay(1);
      setModalShow(true);
    }
  }

  function handleEdit() {
    if (hasSelectItem === true) {
      const index = Object.values(selectedItem);
      //console.log(selectedItem);

      const selectedProduct1 = order[selectedTab][index as any]; // Get the product

      //console.log(Object.values(selectedProduct1.specifications).flat());
      setExistSpecs(
        Object.values(selectedProduct1.specifications).flat() as any
      );

      axios
        .post(
          `${localhost}:3001/Products/${order[selectedTab][index as any].category
          }`
        )

        .then((response) => {
          ////console.log(response.data + "the product created succesfully");

          let id =
            order[Object.keys(selectedItem)[0]][Object.values(selectedItem)[0]]
              .id;

          for (const product of Object.values(response.data["products"])) {
            console.log(product);
            if (id === Object.keys(product as any).toString()) {
              for (const price of Object.values(product as any)) {
                setStartingPrice(
                  parseFloat(Object.values(price as any)[0] as any)
                );
              }
              break; // Διακόπτει τον εξωτερικό βρόχο όταν βρεθεί το προϊόν
            }
          }
          let data =
            response.data[`${order[selectedTab][index as any].category}`];
          console.log("here is the data");
          console.log(
            response.data[`${order[selectedTab][index as any].category}`]
          );
          let category_options = data;
          setCategory(data);
          console.log(category_options);
          let tempExtraCosts: { [key: string]: number[] } = {};
          setCategoryOptions({});

          //take category specs
          ////console.log("hello the first" + res[key]);

          category_options.forEach((element: any) => {
            const name = Object.keys(element)[0]; // Get the dynamic key (e.g., Ποσότητα)
            const specs: Object[] = [];

            // Populate the specs array
            element[name].forEach((spec: any) => {
              let cost = {};
              specs.push(Object.keys(spec)); // Extract each spec key (e.g., Κανονικό, Διπλό)
              cost = Object.values(spec);
              ////console.log(cost + "her is the cost");
              if (!tempExtraCosts[name]) {
                tempExtraCosts[name] = [];
              }
              // Add numeric costs to the temporary array
              tempExtraCosts[name].push(cost as number);
            });

            // Dynamically update the categoryOptions state
            setCategoryOptions((prevOptions) => ({
              ...prevOptions,
              [name]: specs, // Add the dynamic key (e.g., Ποσότητα: ["Κανονικό", "Διπλό"])
            }));
          });

          setShowSpecModal(true);
        })

        .catch((error) => {
          console.error("There was an error!", error);
        });
    }
  }

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let contains = existSpec.includes(Object.values(e)[0]);
    if (contains) {
      setExistSpecs((prevSpecs) =>
        prevSpecs.filter((spec) => (spec as any) !== Object.values(e)[0])
      );
    } else {
      setExistSpecs((prevSpecs) => [...prevSpecs, Object.values(e)[0]]);
    }
  };

  function handleDelete() {
    //function for the delete button to remove one product from order
    if (hasSelectItem === true) {
      //console.log(Object.keys(selectedItem));
      let key = Object.keys(selectedItem);
      let index = Object.values(selectedItem);

      setDeleteditems((prevDeleteItems) => {
        const updatedDeleteItems = { ...prevDeleteItems };
        const itemToDelete = order[key as any][index as any];
        if (!updatedDeleteItems[key as any]) {
          updatedDeleteItems[key as any] = []; // initialize the array if it's empty
        }
        updatedDeleteItems[key as any] = [
          ...updatedDeleteItems[key as any],
          itemToDelete,
        ]; // add item to the key you want

        return updatedDeleteItems;
      });
      setStartingOrder((prevOrder) => {
        const updatedOrder = { ...prevOrder };
        const updatedArray = [...(updatedOrder[key as any] || [])];
        updatedArray.splice(index as any, 1);
        updatedOrder[key as any] = updatedArray;
        setSelectedView(updatedOrder[key as any]);
        // Return the updated order to update the state
        return updatedOrder;
      });
      //console.log(deleteItems);
      setOrder((prevOrder) => {
        const updatedOrder = { ...prevOrder };
        const updatedArray = [...(updatedOrder[key as any] || [])];
        updatedArray.splice(index as any, 1);
        updatedOrder[key as any] = updatedArray;
        setSelectedView(updatedOrder[key as any]);
        // Return the updated order to update the state
        return updatedOrder;
      });
    }
  }
  function changeProduct() {
    if (category !== null) {
      let extraCost = 0;
      Object.entries(category).forEach((element: any) => {
        Object.entries(element[1]).forEach((item: any) => {
          Object.values(item[1]).forEach((value: any) => {
            //console.log(value);

            //  console.log(Object.keys(value));

            const item = Object.keys(value).flat();
            // console.log(existSpec);
            const contain = item.some((key) => existSpec.includes(key));
            if (contain) {
              //console.log("yeah");
              //console.log(Object.values(value));

              const valueArray = Object.values(value);

              const sum = valueArray.reduce(
                (accumulator: number, current: any) => {
                  return (
                    accumulator + (typeof current === "number" ? current : 0)
                  );
                },
                0
              );

              extraCost += sum as number;
              //console.log(extraCost.toFixed(2) + " here is the extra cost");
            } else {
              console.log("false");
            }
          });
        });
      });
      let newspecs = [];
      setOrder((prevOrder) => {
        const updatedOrder = { ...prevOrder };

        const tab = Object.keys(selectedItem)[0];
        const index = Object.values(selectedItem)[0];
        console.log(updatedOrder[tab][index].specifications);
        console.log(existSpec);
        for (let i = 0; i < existSpec.length; i++) {
          console.log(existSpec[i]);
          const spec = [existSpec[i]];
          newspecs.push(spec);
        }

        console.log(typeof startingPrice);
        console.log(typeof extraCost);
        if (updatedOrder[tab] && updatedOrder[tab][index] !== undefined) {
          updatedOrder[tab][index] = {
            ...updatedOrder[tab][index],
            price: startingPrice + extraCost, // Add price and extraCost
            specifications: newspecs,
          };
        }

        return updatedOrder; // Return the modified object to set the state
      });
    }
  }
  return (
    <>
      <Edit_Comp
        isVisible={modalShow}
        onClose={() => setModalShow(false)}
        table={table}
        editWay={editWay}
        tab={selectedTab}
        modifiedItems={modified}
        dataToEdit={order[selectedTab]}
        deleteItems={deleteItems}
      ></Edit_Comp>
      <Modal
        show={showSpecModal}
        onHide={() => setShowSpecModal(false)}
        animation={false}
        centered
      >
        <Modal.Header
          closeButton
          style={{ background: "orange", color: "white" }}
        >
          Διαλέξτε τα χαρακτηριστικά του προιόντος
        </Modal.Header>
        <Modal.Body className="p-0">
          {Object.entries(categoryOptions).map(([key, values]) => (
            <div style={{ lineHeight: "0.9em" }} className="w-100" key={key}>
              <h6 className="text-left text-capitalize ps-1 border-dark border-bottom border-top">
                {key}
              </h6>
              <div className="row no-gutters ps-1 pe-1 text-left align-items-center">
                {values.map((value, index) => {
                  let isChecked = existSpec.includes(Object.values(value)[0]);
                  // Check if value exists in the flattened array// Adjust this check if specs structure differs

                  return (
                    <div className="col-4 mt-1 mb-1 d-flex" key={value as any}>
                      <input
                        type="checkbox"
                        id={`${key}-${value}`}
                        value={value as any}
                        checked={isChecked} // Use checked to track dynamic changes
                        onChange={() => handleCheckboxChange(value as any)}
                      />
                      <label className="ps-1" htmlFor={`${key}-${value}`}>
                        <div style={{ fontSize: "16px" }}>
                          {value as any}
                          {isChecked}
                        </div>
                      </label>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </Modal.Body>
        <Button
          style={{ display: "block" }}
          type="submit"
          variant="primary"
          className="edit-menu-button mb-2 mt-2 border border-dark bg-secondary text-white m-auto"
          onClick={() => {
            changeProduct();
            setShowSpecModal(false);
          }}
        >
          Edit Product
        </Button>
      </Modal>
      <div className="row p-0">
        <div
          className="col-12 d-flex border-right border-dark p-0"
          style={{ background: "#222222" }}
        >
          <Order_Tab onClickChooseTab={handleTab} tabs={tabs} />
        </div>
      </div>

      <div className="row p-0 no-gutters">
        <div className="col-9">
          {view.map((item, index) => (
            <Payment_Products
              key={index}
              id={item.id}
              price={item.price}
              category={item.category}
              specifications={item.specifications}
              onclickIdChoose={() => handleSelectedProduct(index)}
              selected={selectedItem[selectedTab] === index}
            />
          ))}
        </div>

        <div
          className="col-3 d-flex flex-column gap-5 justify-content-center align-items-center bg-light"
          style={{ background: "lightgray", minHeight: "100vh" }}
        >
          <Button
            className="btn btn-sm edit-menu-button border border-dark bg-secondary text-white p-3 px-md-5 py-md-3 me-1 mt-5"
            onClick={() => handleEdit()}
          >
            <div className="d-flex flex-column  text-center p-0">
              <i className="fas fa-edit fa-2x"></i>
            </div>
          </Button>
          <Button
            className="btn btn-sm edit-menu-button border border-dark bg-danger text-white p-3 px-md-5 py-md-3 me-1"
            onClick={() => handleDelete()}
          >
            <div className="d-flex flex-column text-center p-0">
              <i className="fa fa-trash fa-2x"></i>
            </div>
          </Button>

          <Button
            className="btn btn-sm edit-menu-button border border-dark bg-secondary text-white p-3 px-md-5 py-md-3 me-1 mt-8"
            onClick={() => discardChanges()}
          >
            <div className="d-flex flex-column text-center p-0">
              <i className="fas fa-undo fa-2x"></i>
            </div>
          </Button>
          <Button
            className="btn btn-sm edit-menu-button border border-dark bg-secondary text-white p-3 px-md-5 py-md-3 me-1"
            onClick={() => handleModal(1)}
          >
            <div className="d-flex flex-column text-center p-0">
              <i className="fas fa-save fa-2x"></i>
            </div>
          </Button>
          <Button
            className="btn btn-sm edit-menu-button border border-dark bg-secondary text-white p-3 px-md-5 py-md-3 me-1 mb-3"
            onClick={() => handleModal(2)}
          >
            <div className="d-flex flex-column text-center p-0">
              <i className="fa-solid fa-print fa-2x"></i>
            </div>
          </Button>
        </div>
      </div>
    </>
  );
}

export default Order_View;
