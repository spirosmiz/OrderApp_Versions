import "../index.css";
import "../sass/bootstrap.scss";
import "../sass/font-awesome.scss";

import React, {
  useState,
  ReactNode,
  useEffect,
  PropsWithChildren,
  Children,
} from "react";

import { motion, MotionProps } from "framer-motion";

export type Myprops = {
  id: string;
  price: number;
  quantity: number;
  category: string;

  onclickIdIncrease: (
    id: string,
    price: number,
    quantity: number,
    category: string
  ) => void;
  onclickIdDecrease: (
    id: string,
    price: number,
    quantity: number,
    category: string
  ) => void;
};

export default function MyProduct({
  id,
  price,
  onclickIdIncrease,
  onclickIdDecrease,
  category,
}: Myprops) {
  const [quantity, setQuantity] = useState(0);

  function increaseQuantity() {
    setQuantity((prevQuantity) => prevQuantity + 1);
  }

  function decreaseQuantity() {
    setQuantity((prevQuantity) => {
      if (prevQuantity > 0) {
        return prevQuantity - 1;
      } else {
        return prevQuantity; // Or handle the case when quantity is 0
      }
    });
  }

  return (
    <>
      <div
        className="row d-flex payment_products"
        onClick={() => {
          increaseQuantity();
          onclickIdIncrease(id, price, quantity, category);
        }}
      >
        <div className="col-10 text-nowrap text-start ms-2 mb-2 font_size_prod ">
          {id}
        </div>
        <div className="col-1 text-nowrap text-end mb-2 font_size_prod ">
          {price} €
        </div>
      </div>
    </>
  );
}
