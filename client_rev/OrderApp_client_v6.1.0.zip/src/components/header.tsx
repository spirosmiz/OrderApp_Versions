import { motion } from "framer-motion";
import { Dropdown } from "react-bootstrap";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import "./products";
import React, { FormEvent } from "react";
import { useRef, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../index.css";
import { useAlert } from "./Modals/alert";
const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
export default function Header() {
  const navigate = useNavigate();
  const imageSrc = useRef();
  const { showAlert } = useAlert();
  const [showSpinner, setShowSpinner] = useState(false);
  const [successProduct, setsuccessProduct] = useState("Submit");
  const [successCategory, setsuccessCategory] = useState("Submit");

  const [serverCategories, setServerCategories] = useState([]);
  function handleNavigate() {
    navigate("/edit");
  }

  function takeCategories() {
    axios
      .post(`${localhost}:3001/categoryNames`)

      .then((response) => {
        //console.log(response.data + "the product created succesfully");
        setServerCategories(response.data);
        //console.log(response.data);
      })
      .catch((error) => {
        if (error.response) {
          console.log(error.response.data);
          showAlert(error.response.data || "Σφάλμα από τον server");
        } else if (error.request) {
          showAlert(
            "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
          );
        } else {
          showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
        }
      });
  }

  const renderModalBody = () => {
    if (successProduct === "Submit") {
      return (
        <>
          <Modal.Header closeButton onClick={handleCloseCheckOpenForm}>
            Θέλετε να καταχωρήσετε το προίον ?
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column ">
            <Button
              onClick={handleSubmitProduct}
              type="submit"
              variant="primary"
              className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
            >
              {showSpinner ? <i className="fa fa-spinner fa-spin"></i> : "Ναι"}
            </Button>

            <Button
              type="submit"
              variant="primary"
              className={`edit-menu-button border border-dark mt-2 mb-2 ${showSpinner ? "disabled" : ""
                }`}
              onClick={handleCloseCheckOpenForm}
            >
              Όχι
            </Button>
          </Modal.Body>
        </>
      );
    } else if (successProduct === "Success Submit") {
      return (
        <>
          <Modal.Header closeButton onClick={handleCloseForms}>
            Το προίον καταχωρήθηκε επιτυχως
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column ">
            <div className="circular-icon" style={{ padding: "interhit" }}>
              <i className="fa-solid fa-check fa-3x bg-success rounded rounded-circle"></i>
            </div>
          </Modal.Body>
        </>
      );
    } else if (successProduct === "Product Exist") {
      return (
        <>
          <Modal.Header closeButton onClick={handleCloseCheckOpenForm}>
            Το προίον δεν καταχωρήθηκε διότι υπάρχει ήδη στο menu.
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column ">
            <div className="circular-icon">
              <i className="fa-solid fa-x fa-2x bg-danger rounded rounded-circle "></i>
            </div>
          </Modal.Body>
        </>
      );
    }
  };

  const renderModalBodyCategory = () => {
    if (successCategory === "Submit") {
      return (
        <>
          <Modal.Header closeButton onClick={handleCloseCheckOpenFormCategory}>
            Θέλετε να καταχωρήσετε την κατηγορία?
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column ">
            <Button
              onClick={handleSubmitCategory}
              type="submit"
              variant="primary"
              className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
            >
              {showSpinner ? <i className="fa fa-spinner fa-spin"></i> : "Ναι"}
            </Button>

            <Button
              type="submit"
              variant="primary"
              className={`edit-menu-button border border-dark mt-2 mb-2 ${showSpinner ? "disabled" : ""
                }`}
              onClick={handleCloseCheckOpenFormCategory}
            >
              Όχι
            </Button>
          </Modal.Body>
        </>
      );
    } else if (successCategory === "Success Submit") {
      return (
        <>
          <Modal.Header closeButton onClick={handleCloseCheckOpenFormCategory}>
            Η κατηγορία καταχωρήθηκε επιτυχώς.
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column ">
            <div className="circular-icon" style={{ padding: "interhit" }}>
              <i className="fa-solid fa-check fa-3x bg-success rounded rounded-circle"></i>
            </div>
          </Modal.Body>
        </>
      );
    } else if (successCategory === "Category Exist") {
      return (
        <>
          <Modal.Header closeButton onClick={handleCloseCheckOpenFormCategory}>
            Η κατηγορία δεν καταχωρήθηκε γιατί υπάρχει ήδη.
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column  justify-content-center">
            <div className="circular-icon">
              <i className="fa fa-times fa-2x bg-danger rounded rounded-circle p-2 "></i>
            </div>
          </Modal.Body>
        </>
      );
    }
  };

  const [show, setShow] = useState(false); //add product hook
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [showCheck, setShowCheck] = useState(false); //check add product hoos
  const handleShowCheck = () => setShowCheck(true);
  const handleCloseCheck = () => setShowCheck(false);

  const [showCheckCategory, setShowCheckCategory] = useState(false); //check add product hoos
  const handleShowCheckCategory = () => setShowCheckCategory(true);
  const handleCloseCheckCategory = () => {
    console.log(value_options);
    setShowCheckCategory(false);
    setsuccessCategory("Submit");
  };

  const handleAddProduct = () => {
    setShow(false); // Close "Add Product Product" modal
    setShowCheck(true); // Open "Confirm Add Product" modal
    setShowSpinner(false);
  };

  const handleCloseForms = () => {
    setShow(false); // Close "Add Product Product" modal
    setShowCheck(false); // Open "Confirm Add Product" modal
    setsuccessProduct("Submit");
    setsuccessCategory("Submit");
  };
  const handleCloseCheckOpenForm = () => {
    setShow(true); // Close "Add Product Product" modal
    setShowCheck(false); // Open "Confirm Add Product" modal
    setsuccessProduct("Submit");
    setsuccessCategory("Submit");
  };

  const category_name = useRef<HTMLSelectElement>(null);
  const name = useRef<HTMLInputElement>(null);
  const price = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    id: "enteredName",
    price: 0,
    category: "",
  });

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    //submit form and the taking the current values
    event.preventDefault();
    const enteredCategory = category_name.current!.value;
    const enteredName = name.current!.value;
    const enteredPrice = parseFloat(price.current!.value);
    const newProduct = {
      id: enteredName,
      price: enteredPrice,
      category: enteredCategory,
    };

    // save the form data in state
    setFormData(newProduct);
    handleAddProduct();
  }
  function handleSubmitProduct() {
    //method for submit the new product to base
    setShowSpinner(true);
    const finalformData = {
      [formData.id]: {
        price: `${formData.price}`,
        category: `${formData.category}`,
      },
    };
    //console.log(finalformData);

    //const finalProduct = JSON.stringify(formData);
    ////console.log(finalProduct, "  here is the specs of new product");
    axios
      .post(`${localhost}:3001/addProduct`, finalformData)

      .then((response) => {
        //console.log(response.data + "the product created succesfully");
        setsuccessProduct(response.data);
      })
      .catch((error) => {
        if (error.response) {
          console.log(error.response.data);
          showAlert(error.response.data || "Σφάλμα από τον server");
        } else if (error.request) {
          showAlert(
            "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
          );
        } else {
          showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
        }
      });
  }

  async function handleSubmitCategory() {
    //method for submit the new product to base
    setShowSpinner(true);
    console.log(imageSrc);
    //const finalProduct = JSON.stringify(formData);
    ////console.log(finalProduct, "  here is the specs of new product");
    let firstresponse;
    try {
      const dataresponse = await axios
        .post(`${localhost}:3001/addCategory`, dataCategory)

        .then((response) => {
          firstresponse = response.data;
          setsuccessCategory(response.data);
        });
    } catch (error) {
      if (error) {
        console.log(error);
        showAlert(error || "Σφάλμα από τον server");
      } else if (error) {
        showAlert(
          "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
        );
      } else {
        showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
      }
    }

    console.log(firstresponse + " the first response");
    if (firstresponse !== "Category Exist") {
      console.log(firstresponse + "hello");
      const data = new FormData();
      const newFileName = `${Object.keys(dataCategory)[0]}.jpg`; // Μπορείς να προσαρμόσεις την επέκταση αν χρειάζεται

      // Δημιουργούμε ένα νέο αντικείμενο File με το νέο όνομα
      const renamedFile = new File([imageCategory], newFileName, {
        type: imageCategory.type,
      });

      // Προσθέτουμε το renamedFile στο FormData
      data.append("file", renamedFile);
      console.log(renamedFile);
      try {
        const response = await axios.post(
          `${localhost}:3001/addPhotoCategory`,
          data,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        console.log(response.data + "hello "); // Εμφάνιση απάντησης από τον server
      } catch (error) {
        console.error("Σφάλμα κατά την αποστολή των αρχείων:", error);
      }
    }
  }

  const [showCategory, setShowCategory] = useState(false); //add product hook
  const handleCloseCategory = () => {
    setShowCategory(false);
    setSelectedSpec(0);
    setSpecOptions([]);
    setSpecValues([]);
    setValueOptions([]);
    setValueOptionsPrices([]);
  };
  const handleShowCategory = () => setShowCategory(true);
  const handleAddCategory = () => {
    setShowCategory(false); // Close "Add Product Product" modal
    setShowCheckCategory(true); // Open "Confirm Add Product" modal
    setShowSpinner(false);
  };

  const handleCloseFormsCategory = () => {
    setShowCategory(false); // Close "Add Product Product" modal
    setShowCheckCategory(false); // Open "Confirm Add Product" modal
    setsuccessCategory("Submit");
  };
  const handleCloseCheckOpenFormCategory = () => {
    setShowCategory(true);
    setShowCheckCategory(false);
    setsuccessCategory("Submit");
  };

  const category_specs = useRef<HTMLSelectElement>(null);
  const [selectedSpec, setSelectedSpec] = useState<number>(0); //number of specs
  const [dataCategory, setDataCategory] = useState<{ [key: string]: any }>({});
  function handlePrepareCategory(event: FormEvent<HTMLFormElement>) {
    //submit form and the taking the current values
    event.preventDefault();
    const specsNumber = parseInt?.(category_specs.current!.value);
    /*/console.log(
      category_specs.current!.value,
      name.current!.value,
      specOptions,
      specValues,
      valueOptions,
      value_options_prices
    );/*/
    var finalDataCategory: { [key: string]: any } = {
      [name.current!.value]: [],
    };
    // Loop through specValues and valueOptions
    for (let i = 0; i < specsNumber; i++) {
      let finalSpecCategory: { [key: string]: any } = {
        [specValues[i]]: [],
      };
      //console.log(finalSpecCategory);
      for (let k = 0; k < specOptions[i]; k++) {
        //console.log(valueOptions[i][k]);
        // console.log(valueOptionsPrices[i][k]);
        if (valueOptionsPrices?.[i]?.[k] === undefined) {
          finalSpecCategory[specValues[i]].push({
            [valueOptions[i][k]]: 0,
          });
        } else {
          finalSpecCategory[specValues[i]].push({
            [valueOptions[i][k]]: valueOptionsPrices[i][k],
          });
          //  console.log(finalSpecCategory);
        }
      }
      //console.log(finalSpecCategory, "here is the final category");
      finalDataCategory[name.current!.value].push(finalSpecCategory);
    }
    //console.log(finalDataCategory);

    setDataCategory(finalDataCategory);
    // console.log(finalDataCategory);
    //console.log(dataCategory);
    handleAddCategory();
  }
  const spec_options = useRef<HTMLInputElement>(null);
  const spec_values = useRef<HTMLInputElement>(null);
  const value_options = useRef<HTMLInputElement>(null);
  const value_options_prices = useRef<HTMLInputElement>(null);
  let [specOptions, setSpecOptions] = useState<number[]>([]); //number of options of every spec
  let [specValues, setSpecValues] = useState<string[]>([]); //value of every spec
  let [valueOptions, setValueOptions] = useState<string[][]>([]); //value of every spec
  let [valueOptionsPrices, setValueOptionsPrices] = useState<number[][]>([]); //value price  of every spec

  //const valueSpec = useRef<HTMLInputElement>(); //values of options for every spec
  const handleCategorySpecs = (ref: React.RefObject<HTMLSelectElement>) => {
    //define the number of specs

    if (ref?.current?.value) {
      const value = parseInt(ref?.current?.value, 10);
      //console.log("hello");
      if (value != null && value < selectedSpec) {
        setSelectedSpec(value);
        //console.log("array want to be smaller ", value);
        //console.log("array want to be smaller ", valueOptions);
        specOptions = specOptions.slice(0, value);
        specValues = specValues.slice(0, value);
        valueOptions = valueOptions.slice(0, value);
        valueOptionsPrices = valueOptionsPrices.slice(0, value);
        setSpecOptions(specOptions);
        setSpecValues(specValues);
        setValueOptions(valueOptions);
        setValueOptionsPrices(valueOptionsPrices);
      } else {
        setSelectedSpec(value);
        //console.log("array want to be bigger ", value);
        //console.log(specOptions);
      }
    }
  };

  const handleSpecOptions = (index: number, value: number) => {
    //defines the value of options of a spec
    setSpecOptions((prevSpecOptions) => {
      // Create a new array with the updated value`
      const newSpecOptions = [...prevSpecOptions];
      newSpecOptions[index] = value;
      return newSpecOptions;
    });
  };
  const handleSpecValues = (index: number, value: string) => {
    //defines the value of options of a spec
    setSpecValues((prevSpecValues) => {
      // Create a new array with the updated value`
      const newSpecValues = [...prevSpecValues];
      newSpecValues[index] = value;
      return newSpecValues;
    });
  };

  const handleValueOptions = (index: number, i: number, value: string) => {
    let newValueOptionsCopy = [...valueOptions];
    let newValueOptions = Array.from({ length: selectedSpec }, (_, i) =>
      Array.from({ length: specOptions[i] || 0 }, () => " ")
    );

    if (newValueOptionsCopy.length === 0) {
      newValueOptionsCopy = [...newValueOptions];
      newValueOptionsCopy[i][index] = value;
    } else {
      for (let k = 0; k < newValueOptionsCopy.length; k++) {
        for (let z = 0; z < newValueOptionsCopy[k].length; z++) {
          newValueOptions[k][z] = newValueOptionsCopy[k][z];
        }
        newValueOptions[i][index] = value;
      }
    }
    setValueOptions(newValueOptions);
  };

  const handleValueOptionsPrices = (
    index: number,
    i: number,
    value: number
  ) => {
    // console.log("here is the value", value);
    //  console.log("array want to be smaller ", specOptions);
    let newValueOptionsCopy = [...valueOptionsPrices];
    let newValueOptions = Array.from({ length: selectedSpec }, (_, i) =>
      Array.from({ length: specOptions[i] || 0 }, () => 0)
    );
    //console.log(newValueOptions.length, newValueOptions);

    if (newValueOptionsCopy.length === 0) {
      newValueOptionsCopy = [...newValueOptions];
      newValueOptionsCopy[i][index] = value;
    } else {
      for (let k = 0; k < newValueOptionsCopy.length; k++) {
        for (let z = 0; z < newValueOptionsCopy[k].length; z++) {
          newValueOptions[k][z] = newValueOptionsCopy[k][z];
        }
        newValueOptions[i][index] = value;
      }
    }

    //console.log(newValueOptionsCopy);
    // console.log(newValueOptions);
    setValueOptionsPrices(newValueOptions);
  };
  const [fileName, setFileName] = useState<any>();
  const [imageCategory, setImageCategory] = useState<File | any>();

  function handleChangeImage(event: React.ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];

    if (file) {
      const imageURL = URL.createObjectURL(event.target.files?.[0] as any);
      console.log(imageURL + "hello");
      setFileName(event.target.files?.[0].name as any);
      setImageCategory(file);
    }
  }
  const renderSpecs = () => {
    const inputs = [];

    for (let i = 0; i < selectedSpec; i++) {
      inputs.push(
        <div
          key={i}
          className="d-flex justify-content-evenly align-content-center flex-wrap border-dark border-bottom mt-3"
        >
          <input
            placeholder="Spec Name"
            key={i}
            className="rounded w-50 edit-menu-inputs mb-2"
            type="text"
            id={`${i}`}
            name={`${i}`}
            ref={spec_values}
            value={specValues[i]}
            required
            onChange={(e) => handleSpecValues(i, e.target.value)}
          ></input>
          <input
            placeholder="Options"
            type="number"
            name="category_options"
            className="rounded mb-2 w-25 edit-menu-inputs border border-dark"
            min={0}
            defaultValue={0}
            ref={spec_options}
            value={specOptions[i]}
            required
            onChange={(e) => handleSpecOptions(i, parseInt(e.target.value, 10))}
          ></input>

          {Array.from({ length: specOptions[i] }, (_, index) => (
            <div className="row mt-1 mb-1">
              <div className="col-6 d-flex flex-row no-gutters">
                <div key={index * i}>
                  <label htmlFor={`input-${i}-${index}`}>
                    Option {index + 1}
                  </label>

                  <input
                    className="rounded edit-menu-inputs"
                    type="text"
                    id={`input-${i}-${index}`}
                    name={`input-${i}-${index}`}
                    ref={value_options}
                    onChange={(e) =>
                      handleValueOptions(index, i, e.target.value)
                    }
                    required
                  />
                </div>
              </div>
              <div className="col-6 d-flex flex-column justify-content-center aling-items-center">
                <div
                  className="d-flex flex-column justify-content-center align-items-center"
                  key={index * i}
                >
                  <label htmlFor={`input-${i}-${index}`}>
                    Extra Value {index + 1}
                  </label>
                  <input
                    className="rounded width_class"
                    type="number"
                    defaultValue={0}
                    step={0.1}
                    id={`input-${i}-${index}`}
                    name={`input-${i}-${index}`}
                    ref={value_options_prices}
                    onChange={(e) =>
                      handleValueOptionsPrices(index, i, e.target.valueAsNumber)
                    }
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      );
    }
    return inputs;
  };

  return (
    <>
      <div className="row">
        <div className="col-12">
          <motion.div
            className="header d-flex justify-content-between align-items-center"
            style={{ backgroundColor: "#222" }}
          >
            <motion.span
              className="text-center"
              style={{
                fontSize: "1.2rem",
                fontFamily: "sans-serif",
                color: "white",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
              }}
            >
              <motion.div
                initial={{ x: "-50%" }}
                transition={{ duration: 0.5 }}
                animate={{
                  x: 0,
                  position: "relative",
                  transitionEnd: {
                    display: "block",
                  },
                }}
              >
                La Place Cafe App
              </motion.div>
            </motion.span>
            <motion.div
              initial={{ x: "50%" }}
              transition={{ duration: 0.5 }}
              animate={{
                x: 0,
                position: "relative",
                transitionEnd: {
                  display: "block",
                },
              }}
            ></motion.div>

            <Dropdown>
              <Dropdown.Toggle
                id="dropdown-basic "
                className="text-end text-white borderless"
                style={{
                  background: "transparent",
                  padding: "interhit",
                  border: "none",
                }}
              >
                <i className="fa fa-cog text-white" aria-hidden="true"></i>
              </Dropdown.Toggle>
              <Dropdown.Menu className="edit_header">
                <Dropdown.Item onClick={handleShowCategory}>
                  Add Category
                </Dropdown.Item>
                <Dropdown.Item
                  onClick={() => {
                    takeCategories();
                    handleShow();
                  }}
                >
                  Add Product
                </Dropdown.Item>
                <Dropdown.Item
                  onClick={() => {
                    handleNavigate();
                  }}
                >
                  Edit
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </motion.div>
        </div>
      </div>

      <Modal
        className="modal-header modal-product m-auto text-center"
        show={show}
        onHide={handleClose}
        animation={false}
      >
        <Modal.Header closeButton>
          Διαλέξτε τα χαρακτηριστικά του προιόντος
        </Modal.Header>
        <Modal.Body>
          <form
            onSubmit={handleSubmit}
            className="form-product d-flex flex-column justify-content-center align-items-center"
          >
            <label className="fw-bolder " htmlFor="category">
              Select Category
            </label>

            <select
              id="category p-2"
              className="rounded edit-menu-inputs"
              name="category_name"
              ref={category_name}
            >
              {serverCategories.map((category) => (
                <option>{category}</option>
              ))}
            </select>

            <div className="pt-2">
              <label htmlFor="price">Enter the name of the product</label>
              <input
                className="rounded w-50 edit-menu-inputs"
                type="text"
                id="name"
                ref={name}
                required
              />
            </div>
            <div className="text-center pt-2">
              <label htmlFor="price">Enter the price of the product</label>
              <input
                className="rounded w-50 edit-menu-inputs"
                type="number"
                id="price"
                ref={price}
                step={0.1}
                required
              />
            </div>
            <Button
              type="submit"
              variant="primary"
              className="edit-menu-button border mt-2 border-dark bg-secondary text-white  "
            >
              Add Product
            </Button>
          </form>
        </Modal.Body>
      </Modal>

      <Modal
        className="modal-header modal-product m-auto text-center "
        show={showCheck}
        onHide={handleCloseCheck}
        animation={false}
      >
        {renderModalBody()}
      </Modal>

      <Modal
        className="modal-header modal-product m-auto text-center"
        show={showCategory}
        onHide={handleCloseCategory}
        animation={false}
      >
        <Modal.Header
          closeButton
          className="d-flex flex-column-reverse justify-content-center"
        >
          Διαλέξτε τα χαρακτηριστικά της κατηγορίας
        </Modal.Header>
        <Modal.Body>
          <form
            onSubmit={handlePrepareCategory}
            className="form-product d-flex flex-column justify-content-center align-items-center"
          >
            <div className="d-flex gap-3">
              <input
                placeholder="Category Name"
                className="rounded w-50 edit-menu-inputs"
                type="text"
                id="name"
                ref={name}
                required
              />

              <label
                htmlFor="file-input"
                className="w-50 edit-menu-button border  border-dark bg-secondary text-white p-1 rounded"
              >
                <div>{fileName != null ? `${fileName}` : "Image"}</div>
                <input
                  onChange={handleChangeImage}
                  required
                  type="file"
                  ref={imageSrc as any}
                  id="file-input"
                  style={{ display: "none" }}
                  accept=".jpg,.png,"
                />
              </label>
            </div>
            <label className="fw-bolder " htmlFor="category">
              Specs
            </label>

            <select
              id="category p-2"
              className="rounded"
              name="category_specs"
              ref={category_specs}
              onChange={() => handleCategorySpecs(category_specs)}
              required
            >
              <option value="0">0</option>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
            </select>
            {renderSpecs()}

            <Button
              type="submit"
              variant="primary"
              className="edit-menu-button border mt-2 border-dark bg-secondary text-white"
            >
              Add Category
            </Button>
          </form>
        </Modal.Body>
      </Modal>
      <Modal
        className="modal-header modal-product m-auto text-center "
        show={showCheckCategory}
        onHide={handleCloseCheckCategory}
        animation={false}
      >
        {renderModalBodyCategory()}
      </Modal>
    </>
  );
}
