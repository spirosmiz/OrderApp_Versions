import "../index.css";
import "../sass/bootstrap.scss";
import "../sass/font-awesome.scss";
import { ReactNode, useEffect } from "react";
import { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { motion, MotionProps } from "framer-motion";
import { useRef } from "react";
//import imgSrc from "../assets/Drinks.png";
const imgSrc = "../public/assets/";
type ButtonsProps = {
  id: string;
  handleCategory: (id: string) => void;
  img: {
    src: string;
    alt: string;
  };
};

export default function Category_Icons({
  id,
  handleCategory,
  img,
}: ButtonsProps) {
  return (
    <>
      <div className="col-4 col-md-3 mt-2 text-center d-flex  justify-content-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ rotate: 0, scale: 1 }}
          transition={{
            type: "spring",
            stiffness: 260,
            damping: 25,
          }}
        >
          <motion.div
            className="order-border1 me-1 ms-1  bg-dark "
            onClick={() => handleCategory(id)}
          >
            <img
              className="img-fluid text-center position-relative img-specs "
              src={img.src}
              alt={img.alt}
            />
            <div className="d-flex justify-content-center align-items-center p-1 ">
              <motion.div
                animate={{ rotate: 360, scale: 1.1 }}
                transition={{
                  type: "spring",
                  stiffness: 200,
                  damping: 12,
                }}
              >
                <div className="bg-white text-dark  d-flex  justify-content-center align-items-center order-border1 p-1 fw-bold width-text ">
                  {id}
                </div>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </>
  );
}
