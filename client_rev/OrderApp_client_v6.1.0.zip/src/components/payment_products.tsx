import "../index.css";
import "../sass/bootstrap.scss";
import "../sass/font-awesome.scss";

import React, { ReactElement, useState } from "react";

export type Payment_Products_Props = {
  id: string;
  key: number;
  price: number;
  category: string;
  specifications: string[];
  selected: boolean;
  onclickIdChoose: () => void; // Only pass the function, not the key
};

export default function Payment_Products({
  id,
  price,
  specifications,
  category,
  selected,
  onclickIdChoose,
}: Payment_Products_Props) {
  return (
    <>
      <div
        className={`row lh-sm ${selected ? "bg_blue" : "payment_products"}`}
        style={{
          minHeight: specifications.length > 0 ? "auto" : "2.4rem", // Add min-height when specs are missing
        }}
        onClick={() => {
          onclickIdChoose(); // Call the method with the ID passed
        }}
      >
        <div
          className="col-9 d-flex"
          style={{ fontSize: "1rem", lineHeight: "1.2" }}
        >
          <span>{id}</span>
        </div>
        <div
          className="col-3 d-flex justify-content-end"
          style={{ fontSize: "1rem", lineHeight: "1.2" }}
        >
          <span>{price} €</span>
        </div>
        <div
          className="col-12 d-flex text-start add_comma "
          style={{ fontSize: "0.85rem", lineHeight: "1.3" }}
        >
          {specifications.map((spec, index) => (
            <span key={index}>{spec}</span>
          ))}
        </div>
      </div>
    </>
  );
}
