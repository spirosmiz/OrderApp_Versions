import "../index.css";
import "../sass/bootstrap.scss";
import "../sass/font-awesome.scss";

import React, {
  useState,
  ReactNode,
  useEffect,
  PropsWithChildren,
  Children,
} from "react";

import { motion, MotionProps } from "framer-motion";

export type MyOrderprops = {
  id: string;
  price: number;
  quantity: number;
  category: string;
  specifications: string[];

  onclickIdIncrease: (
    id: string,
    price: number,
    quantity: number,
    category: string,
    specifications: string[]
  ) => void;
  onclickIdDecrease: (
    id: string,
    price: number,
    quantity: number,
    category: string,
    specifications: string[]
  ) => void;
  onclickIdDelete: (
    id: string,
    price: number,
    quantity: number,
    category: string,
    specifications: string[]
  ) => void;
};

export default function OrderProducts({
  id,
  price,
  onclickIdIncrease,
  onclickIdDecrease,
  onclickIdDelete,
  quantity,
  category,
  specifications,
}: MyOrderprops) {
  return (
    <>
      <div className="row lh-sm no-gutters">
        <div className="col-6 d-flex text-nowrap text-start justify-content-start fw-bold align-items-center">
          {id}
        </div>

        <div className="col-6 d-flex text-center justify-content-end align-items-center ">
          <motion.div
            whileTap={{ scale: 0.9 }}
            style={{ padding: "inherit" }}
            onClick={() => {
              onclickIdIncrease(id, price, quantity, category, specifications);
            }}
          >
            <i className="symbols fa-solid fa-plus "></i>
          </motion.div>
          <h4 className="mt-2" style={{ width: "14px" }}>
            {quantity}
          </h4>
          <motion.div
            style={{ padding: "inherit" }}
            onClick={() => {
              onclickIdDecrease(id, price, quantity, category, specifications);
            }}
          >
            <i className="symbols fa-solid fa-minus"></i>
          </motion.div>
          <motion.div
            onClick={() =>
              onclickIdDelete(id, price, quantity, category, specifications)
            }
          >
            <i
              className="symbols fa fa-trash"
              style={{ color: "red" }}
              aria-hidden="true"
            ></i>
          </motion.div>
          <h5 className="ms-2 mt-3 text-nowrap">
            {(price * quantity).toFixed(2)} €
          </h5>
        </div>
        <div className="col-12 d-flex flex-row justify-content-start text-start fw-bold align-items-start add_space">
          {specifications.map((spec) => (
            <span>{spec}</span>
          ))}
        </div>
      </div>
    </>
  );
}
