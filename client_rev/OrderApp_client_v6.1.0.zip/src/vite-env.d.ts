/// <reference types="vite/client" />
VITE_API_URL = "http://10.10.10.10/";
interface ImportMetaEnv {
  readonly VITE_API_URL: string;
  // Add more environment variables as needed
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
