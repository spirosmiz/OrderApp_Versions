import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
const localhost = "http://10.10.10.10";
// https://vitejs.dev/config/
export default defineConfig({
  server: {
    host: "localhost",
    //host: "10.10.10.10",
    port: 5173,
    open: true,
    proxy: {
      "/assets": {
        target: `${localhost}:3001`,
        //target: `10.10.10.10:3001`,
        changeOrigin: true,
      },
    },
  },
  plugins: [react()],
});
