import { motion } from "framer-motion";
import { Tabs, Tab } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
export type TabsProps = {
  tabs: string[]; // Array of tab titles
  onClickChooseTab: (id: string, event: any) => void; // Allow event of any type for flexibility
};

export default function Order_Tab({ tabs, onClickChooseTab }: TabsProps) {
  let navigate = useNavigate();
  return (
    <>
      <motion.button
        className="text-nowrap edit-menu-button rounded border mt-2 border-dark bg-white text-dark mt-1 me-1 mr-1 ms-2"
        onClick={() => {
          window.history.back();
        }}
      >
        <i className="fa-solid fa-arrow-left"></i>
        &nbsp;Back
      </motion.button>
      <Tabs
        defaultActiveKey={tabs[0]} // Set the first tab as active by default
        transition={false}
        className="text-danger border-0"
        style={{ background: "#222222" }}
        // Use the onSelect handler to capture tab changes
        onSelect={(eventKey, event) => onClickChooseTab(eventKey as any, event)}
      >
        {tabs.map((element) => (
          <Tab
            className="tab-button"
            id={element}
            eventKey={element}
            title={element.substring(7, 9) + ":" + element.substring(9, 11)}
            key={element}
          ></Tab>
        ))}
      </Tabs>
    </>
  );
}
