import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import "../../index.css";
import { useNavigate } from "react-router-dom";

type Modal_Comp_Props = {
  isVisible: boolean;
  onClose: () => void;
  text: string;
};

export default function Back_Modal({
  isVisible,
  onClose,
  text,
}: Modal_Comp_Props) {
  let navigate = useNavigate();
  function backHist() {
    localStorage.clear();
    window.history.back();
  }
  return (
    <Modal
      className="modal-header modal-product m-auto text-center"
      show={isVisible}
      onHide={onClose}
      animation={false}
    >
      <Modal.Header
        closeButton
        className="d-flex flex-column-reverse justify-content-center align-items-center"
      >
        <div className="w-75">{text}</div>
      </Modal.Header>

      <Modal.Body className="d-flex flex-column">
        <Button className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white">
          <div
            onClick={backHist}
            className="d-flex flex-column text-center p-0"
          >
            Ναι
          </div>
        </Button>

        <Button
          onClick={onClose}
          className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
        >
          <div className="d-flex flex-column text-center p-0">Όχι</div>
        </Button>
      </Modal.Body>
    </Modal>
  );
}
