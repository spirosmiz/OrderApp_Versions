import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import { useState, ReactNode } from "react";
import "../../index.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
type Modal_Comp_Props = {
  isVisible: boolean;
  onClose: () => void;
  table: ReactNode;
  editWay: number;
  tab: string;
  modifiedItems: { [key: string]: any };
  dataToEdit: { [key: string]: any };
  deleteItems: { [key: string]: any };
};

export default function Edit_Comp({
  isVisible,
  onClose,
  table,
  editWay,
  modifiedItems,
  dataToEdit,
  tab,
  deleteItems,
}: Modal_Comp_Props) {
  const [EditType, setEditType] = useState<string | null>(null);
  const [showSpinner, setShowSpinner] = useState(false);
  const [EditStatus, setEditStatus] = useState<string | null>(null);
  let navigate = useNavigate();

  const handleEditSelection = (type: string) => {
    setEditType(type); // Set either 'Cash' or 'Card'
  };

  function handleSubmitEdit() {
    setShowSpinner(true);

    // Simulating Edit processing

    if (editWay === 2) {
      axios
        .post(`${localhost}:3001/rePrint/${table}`)

        .then((response) => {
          setShowSpinner(false);
          if (response.status === 200) {
            setEditStatus("Success");
            setTimeout(() => {
              navigate("/");
            }, 10000);
          } else {
            setEditStatus("Failure");
          }
        })
        .catch((error) => {
          console.error("There was an error!", error);
          setEditStatus("Failure");
          setShowSpinner(false);
        });
    } else if (editWay === 1) {
      console.log(Object.keys(dataToEdit) + "here is the data to pay in modal");
      console.log(modifiedItems);
      let dataToSend = {
        [tab]: dataToEdit,
        modified: Object.values(modifiedItems),
        deleted: Object.values(deleteItems),
      };
      console.log(dataToSend);
      axios
        .post(`${localhost}:3001/changeOrder/${table}`, dataToSend)
        .then((response) => {
          if (response.status === 200) {
            setEditStatus("Success");
            setShowSpinner(false);
            setTimeout(() => {
              navigate("/");
            }, 400);
          } else {
            setEditStatus("Failure");
          }
          setShowSpinner(false);
        })
        .catch((error) => {
          console.error("There was an error!", error);
          setEditStatus("Failure");
          setShowSpinner(false);
        });
      console.log("here is the data to pay in modal");
      console.log(Object.keys(dataToEdit) + "here is the data to pay in modal");
    }
  }

  if (editWay === 1) {
    return (
      <Modal
        className="modal-header modal-product m-auto text-center"
        show={isVisible}
        onHide={onClose}
        animation={false}
      >
        <Modal.Header
          closeButton
          className="d-flex flex-column-reverse justify-content-center align-items-center"
        >
          <div>
            <div>Θέλετε να καταχωρήσετε την τροποποιημένη παραγγελία</div>
          </div>
        </Modal.Header>
        <Modal.Body className="d-flex flex-column">
          <Button
            onClick={() => {
              setEditType("1");
              handleSubmitEdit();
            }}
            type="submit"
            variant="primary"
            className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
          >
            {showSpinner ? <i className="fa fa-spinner fa-spin"></i> : "Ναι"}
          </Button>

          <Button
            className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
            onClick={() => {
              setEditType(null);
              onClose();
            }}
          >
            <div className="d-flex flex-column text-center p-0">Όχι</div>
          </Button>
        </Modal.Body>
      </Modal>
    );
  }
  // Second, handle the case when a Edit type is selected, but no confirmation is done yet
  else if (editWay === 2) {
    return (
      <Modal
        className="modal-header modal-product m-auto text-center"
        show={isVisible}
        onHide={onClose}
        animation={false}
      >
        <Modal.Header
          closeButton
          className="d-flex flex-column-reverse justify-content-center align-items-center"
        >
          <div>
            <div>Θέλετε να επανεκτυπώσετε την παραγγελία?</div>
          </div>
        </Modal.Header>

        <Modal.Body className="d-flex flex-column">
          <Button
            onClick={handleSubmitEdit}
            type="submit"
            variant="primary"
            className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
          >
            {showSpinner ? <i className="fa fa-spinner fa-spin"></i> : "Ναι"}
          </Button>

          <Button
            type="button"
            variant="primary"
            className={`edit-menu-button border border-dark mt-2 mb-2 ${showSpinner ? "disabled" : ""
              }`}
            onClick={() => setEditType(null)}
          >
            Όχι
          </Button>
        </Modal.Body>
      </Modal>
    );
  }
}
