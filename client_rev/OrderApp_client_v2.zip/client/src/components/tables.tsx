import "../index.css";
import "../sass/bootstrap.scss";
import "../sass/font-awesome.scss";
import { ReactNode, useEffect, useRef } from "react";
import { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { motion, MotionProps } from "framer-motion";
import axios from "axios";
import { useAlert } from "./Modals/alert";

const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
export type TableProps = {
  id: string;
  status: string;
  onClickOrder: (id: string, status: string) => void; //method to go to add other order
  onClickPay: (id: string) => void; //method for modal
  onclickView: (id: string) => void;
  onClickAddOrder: (id: string) => void; //method to addOrder
  img: {
    src: string;
    alt: string;
  };
};
export default function Table({
  id,
  status,
  onClickOrder,
  onClickPay,
  onClickAddOrder,
  onclickView,
  img,
}: TableProps) {
  const { showAlert } = useAlert(); // Use the alert from the context
  const parentRef = useRef();
  const [show, setShow] = useState(false); //hook for order payment
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [showTranfserModal, setShowTransferModal] = useState(false); //hook for order payment
  const handleShowTransferModal = () => setShowTransferModal(true);

  const [showCheck, setShowCheck] = useState(false); //hook for order check payment
  const [payment, setPayment] = useState(0);
  const handleCloseCheck = () => setShowCheck(false);
  const handleShowCheck = () => setShowCheck(true);
  const [trId, setTransferID] = useState<number>();
  const [showTransfer, setTransfer] = useState(false);
  const handleCloseTransfer = () => setTransfer(false);
  const handleConfirm = () => setTransfer(true);
  const [my_id, setId] = useState(null);
  const [isPressed, setIsPressed] = useState(false);
  const [secondsPressed, setSecondsPressed] = useState(0);
  const interval = useRef<number | null>(null);
  const transferId = useRef<number | null>(null);
  const [enableButton, setenableButton] = useState(false);
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    const numberValue = Number(value); // Μετατροπή της εισόδου σε αριθμό

    // Έλεγχος αν η τιμή είναι ακέραιος αριθμός
    if (Number.isInteger(numberValue) && numberValue.toString() !== id) {
      transferId.current = numberValue;
      setenableButton(true);
    } else {
      transferId.current = null;
      setenableButton(false);
    }

    console.log("Current transferId:", transferId.current);
    setTransferID(transferId.current as any);
  };
  const handlePressStart = () => {
    console.log("Press started");
    setIsPressed(true);
    setSecondsPressed(0); // Reset the counter when the press starts
  };

  const handlePressEnd = () => {
    setIsPressed(false);
    if (interval.current) {
      clearInterval(interval.current);
      interval.current = null;
    }
    console.log("Final time: ", secondsPressed);
  };

  const [successTransfer, setSuccessTransfer] = useState("Submit");
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSpinner, setShowSpinner] = useState(false);
  const renderModalBody = () => {
    if (successTransfer === "Submit") {
      return (
        <>
          <Modal.Header
            closeButton
            onClick={() => void setShowConfirmModal(false)}
          >
            Θέλετε να μεταφέρετε το τραπέζι ?
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column ">
            <Button
              type="submit"
              variant="primary"
              className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
              onClick={handleSubmitTransfer}
            >
              {showSpinner ? <i className="fa fa-spinner fa-spin"></i> : "Ναι"}
            </Button>

            <Button
              type="submit"
              variant="primary"
              className={`edit-menu-button border border-dark mt-2 mb-2 ${showSpinner ? "disabled" : ""
                }`}
              onClick={() => {
                setShowConfirmModal(false);
                setShowTransferModal(true);
              }}
            >
              Όχι
            </Button>
          </Modal.Body>
        </>
      );
    } else if (successTransfer === "Succesfully transfered") {
      return (
        <>
          <Modal.Header
            closeButton
            onClick={() => {
              void setShowConfirmModal(false);
              reloadwindow();
            }}
          >
            Η Μεταφορά έγινε επιτυχώς
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column ">
            <div className="circular-icon" style={{ padding: "interhit" }}>
              <i className="fa-solid fa-check fa-3x bg-success rounded rounded-circle"></i>
            </div>
          </Modal.Body>
        </>
      );
    }
  };
  function reloadwindow() {
    window.location.reload();
  }
  function handleSubmitTransfer() {
    //method for submit the new product to base
    setShowSpinner(true);

    //console.log(finalformData);

    //const finalProduct = JSON.stringify(formData);
    // console.log(finalProduct, "  here is the specs of new product");
    //console.log(id);
    // console.log(transferId.current);
    axios
      .post(`${localhost}:3001/transferTable/${id}/${trId}`)

      .then((response) => {
        console.log(response.data + "the product created succesfully");
        setSuccessTransfer(response.data);
        console.log(response.data);
      })
      .catch((error) => {
        if (axios.isAxiosError(error)) {
          // Το error είναι τύπου AxiosError
          if (error.response) {
            console.log(error.response.data);
            showAlert(error.response.data || "Σφάλμα από τον server");
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        } else {
          showAlert("Άγνωστο σφάλμα.");
        }
      });
  }

  useEffect(() => {
    if (isPressed && interval.current === null) {
      interval.current = window.setInterval(() => {
        setSecondsPressed((prevSeconds) => {
          const newSeconds = prevSeconds + 0.1;
          if (newSeconds > 3.0) {
            console.log("Seconds exceeded 3.0", newSeconds);
            handlePressEnd(); // Stop pressing when exceeding 3 seconds
          }
          return newSeconds;
        });
      }, 100);
    }

    return () => {
      if (interval.current) {
        clearInterval(interval.current);
        interval.current = null;
      }
    };
  }, [isPressed]);

  const initialPosition = { x: 0, y: 0 };
  const [dragged, setDragStatus] = useState(false);
  const [pos, setPos] = useState(initialPosition);

  return (
    <>
      <Modal
        className="modal-header modal-product m-auto text-center"
        show={show}
        onHide={handleClose}
        animation={false}
      >
        <Modal.Header
          className="d-flex flex-column-reverse fw-bold"
          closeButton
        >
          Select Action
        </Modal.Header>
        <Modal.Body className="d-flex flex-column">
          <div className="row">
            <div className="col-6 d-flex flex-column justify-content-between">
              <Button
                className="edit-menu-button border border-dark bg-secondary text-white bg-success"
                onClick={() => {
                  onClickPay(id);
                }}
              >
                <i className="fa-solid fa-dollar-sign fa-2x"></i>
                <div>Payment</div>
              </Button>
            </div>
            <div className="col-6 d-flex flex-column justify-content-between">
              <Button
                className="edit-menu-button border border-dark  bg-secondary text-dark bg-light"
                onClick={() => {
                  onClickAddOrder(id);
                  handleClose();
                }}
              >
                <i className="fas fa-cart-plus fa-2x"></i>
                <div>Order</div>
              </Button>
            </div>
            <div className="col-6 d-flex flex-column justify-content-between">
              <Button
                className="edit-menu-button border border-dark mt-2  bg-danger text-white"
                onClick={() => {
                  onclickView(id);
                  handleClose();
                }}
              >
                <i className="fa-solid fa-eye fa-2x"></i>
                <div>Εdit</div>
              </Button>
            </div>
            <div className="col-6 d-flex flex-column justify-content-between">
              <Button
                className="edit-menu-button border border-dark mt-2  bg-secondary text-white"
                onClick={() => {
                  handleShowTransferModal();
                  handleClose();
                }}
              >
                <i className="fa fa-exchange fa-2x"></i>
                <div>Transfer</div>
              </Button>
            </div>
          </div>
        </Modal.Body>
      </Modal>

      <motion.div animate={pos} initial={initialPosition}>
        <div
          onClick={() => {
            if (dragged === true) {
            } else {
              if (status === "occupied") {
                handleShow();
              }
            }
            onClickOrder(id, status);
          }}
          className={`table d-flex flex-column justify-content-center align-items-center border border-dark  ${status === "available"
            ? "table-available"
            : "table-unavailabe fa-regular"
            }`}
        >
          <div className="h5 text-center">{id}</div>
          <img className="table-img" src={img.src} alt={img.alt}></img>
        </div>
      </motion.div>

      <Modal
        className="modal-header modal-product m-auto text-center "
        show={showTranfserModal}
        onHide={() => void setShowTransferModal(false)}
        animation={false}
      >
        <Modal.Header closeButton className="d-flex flex-column-reverse">
          <input
            className="rounded w-75 edit-menu-inputs mt-2 mb-2 m-auto text-center"
            type="number"
            step={1}
            onChange={handleInputChange}
            ref={transferId as any}
          ></input>
          <div className="text-center mt-4">
            Σε ποιο τραπέζι θέλετε να μεταφέρετε το τραπέζι <br />
            <span className="fw-bold"> {id}</span>
          </div>
        </Modal.Header>

        <Modal.Body className=" d-flex flex-column ">
          <Button
            type="submit"
            variant="primary"
            className="edit-menu-button border mt-2 border-dark bg-secondary text-white"
            disabled={!enableButton}
            onClick={() => {
              setShowConfirmModal(true);
              setShowTransferModal(false);
            }}
          >
            Επιβεβαίωση
          </Button>
          <Button
            type="submit"
            variant="primary"
            className="edit-menu-button border border-dark mt-2 mb-2"
            onClick={() => void setShowTransferModal(false)}
          >
            Ακύρωση
          </Button>
        </Modal.Body>
      </Modal>
      <Modal
        className="modal-header modal-product m-auto text-center "
        show={showConfirmModal}
        onHide={() => void setShowConfirmModal(false)}
        animation={false}
      >
        {renderModalBody()}
      </Modal>
    </>
  );
}
