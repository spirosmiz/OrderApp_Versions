import { useState, useEffect } from "react";
import MyProduct from "../components/products";
import "../sass/bootstrap.scss";
import "../index.css";
import Button from "react-bootstrap/Button";
import { motion } from "framer-motion";
import { FormEvent } from "react";
import Category_Icons from "./buttons_category";
import axios from "axios";
import OrderProducts from "./order_products";
import Modal from "react-bootstrap/Modal";
import { Form } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";
import { useAlert } from "./Modals/alert";
import Back_Modal from "./Modals/back_modal";
import useLocalStorage from "use-local-storage";

export type CatalogProps = {
  table: string;
  existing_order: any[];
};
export type Myprops1 = {
  id: string;
  price: number;
  quantity: number;
  category: string;
  specifications: string[];
};
export type OrderProps<Myprops1> = {
  order: Myprops1[];
};
const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
function Catalog() {
  const [Images, setImages] = useState();
  const { table } = useParams();
  const { showAlert } = useAlert();
  const [categoriesList, setCategories] = useState<string[]>([]);
  const [categoryOptions, setCategoryOptions] = useState<{
    [key: string]: Object[];
  }>({});
  const [extraCosts, setExtraCosts] = useState<{
    [key: string]: number[];
  }>({});
  function ExtraCosts(tempCosts: { [key: string]: number[] }) {
    setExtraCosts(tempCosts);
  }

  useEffect(() => {
    //takes the data from server to mapping the availabilities of  tables
    async function fetchData() {
      try {
        const response = await axios.post(`${localhost}:3001/categoryNames`);
        console.log(table + "here is the table");
        setCategories(response.data);

        ////console.log(response.data, categoriesList, "the categorie from spiros");
      } catch (error) {
        if (axios.isAxiosError(error)) {
          // Το error είναι τύπου AxiosError
          if (error.response) {
            console.log(error.response.data);
            showAlert(error.response.data || "Σφάλμα από τον server");
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        } else {
          showAlert("Άγνωστο σφάλμα.");
        }

        console.error(error);
      }
    }

    fetchData();
  }, []);

  function handleCategory(category: string) {
    //axios to back-end to take the products of category and its specs for the modal checkbox
    setActiveCategory(category);
    ////console.log(category + "  here is the acrtive category");
    axios
      .post(`${localhost}:3001/Products/${category}`)

      .then((response) => {
        ////console.log(response.data + "hello from back");
        console.log(response.data);
        const res = response.data;
        ////console.log(res + "hello from back 2");
        let count = 0;
        Object.keys(res).forEach((key) => {
          ////console.log(`${key}: ${res[key]}` + "klklkl"); // Key-value pairs in the object
          if (count === 0) {
            let category_options = res[key];
            let tempExtraCosts: { [key: string]: number[] } = {};
            setSelectedProducts([]);
            setCategoryOptions({});
            setExtraCosts({});

            //take category specs
            //console.log("hello the first" + res[key]);

            category_options.forEach((element: any) => {
              const name = Object.keys(element)[0]; // Get the dynamic key (e.g., Ποσότητα)
              const specs: Object[] = [];

              // Populate the specs array
              element[name].forEach((spec: any) => {
                let cost = {};
                specs.push(Object.keys(spec)); // Extract each spec key (e.g., Κανονικό, Διπλό)
                cost = Object.values(spec);
                //console.log(cost + "her is the cost");
                if (!tempExtraCosts[name]) {
                  tempExtraCosts[name] = [];
                }
                // Add numeric costs to the temporary array
                tempExtraCosts[name].push(cost as number);
              });

              // Dynamically update the categoryOptions state
              setCategoryOptions((prevOptions) => ({
                ...prevOptions,
                [name]: specs, // Add the dynamic key (e.g., Ποσότητα: ["Κανονικό", "Διπλό"])
              }));
            });

            console.log(categoryOptions);
            ExtraCosts(tempExtraCosts as any);

            count++;
          } else {
            let products = res[key]; // Get the list of key of products
            const products_list: any[] = [];

            products.forEach((element: any) => {
              //////console.log(element);
              //////console.log(Object.keys(element)[0]);
              const name = Object.keys(element)[0];
              //////console.log(element[name]);
              const product_specs = element[name];
              //////console.log(product_specs["price"]);

              const product = {
                id: name,
                price: product_specs["price"],
                quantity: 0,
                category: product_specs["category"],
                specifications: [],
              };
              products_list.push(product);

              setSelectedProducts(products_list);
              setSelectedValues(
                Object.fromEntries(
                  Object.entries(categoryOptions).map(([key, values]) => [
                    key,
                    values.map(() => false),
                  ])
                )
              );
            });

            count = 0;
          }
          // Do something with each key-value pair
        });
      })
      .catch((error) => {
        if (axios.isAxiosError(error)) {
          // Το error είναι τύπου AxiosError
          if (error.response) {
            console.log(error.response.data);
            showAlert(error.response.data || "Σφάλμα από τον server");
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        } else {
          showAlert("Άγνωστο σφάλμα.");
        }
      });
  }

  let navigate = useNavigate();
  var counterKeys = 0;
  const [productList, setProductList] = useLocalStorage<Myprops1[]>(
    "order",
    []
  );
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const [showModalCategory, setShowModalCategory] = useState(false);
  function handleShowModalCategory(
    id: string,
    price: number,
    quantity: number,
    category: string
  ) {
    handlePrepareProduct(id, price, quantity, category);
    setShowModalCategory(true);
  }

  const [selectedValues, setSelectedValues] = useState(
    //starting the checkboxes all as false
    Object.fromEntries(
      Object.entries(categoryOptions).map(([key, values]) => [
        key,
        values.map(() => false),
      ])
    )
  );

  function handleCheckboxChange(value: string, key: string, index: number) {
    //changes of checkbox
    ////console.log(selectedValues);

    setSelectedValues((prevState) => {
      const updatedArray = prevState[key] ? [...prevState[key]] : [];
      updatedArray[index] = !updatedArray[index];

      return {
        ...prevState,
        [key]: updatedArray,
      };
    });
  }

  function handleProductProps(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    ////console.log(selectedValues);
    let Values = [];
  }

  const [selectedProducts, setSelectedProducts] = useState<Myprops1[]>([]);
  const renderProducts = () => {
    return (
      <ul className="list-unstyled ps-1">
        {selectedProducts.map((product) => (
          <MyProduct
            key={product.id}
            id={product.id}
            quantity={product.quantity}
            price={product.price}
            category={product.category}
            onclickIdIncrease={() =>
              handleShowModalCategory(
                product.id,
                product.price,
                product.quantity,
                product.category
              )
            }
            onclickIdDecrease={handleOrderDecrease}
          />
        ))}
      </ul>
    );
  };

  function sendOrder() {
    // ////console.log("the table which we want for orde is" + table);
    //////console.log(productList);

    const sending = {
      "": productList,
    };
    axios

      .post(`${localhost}:3001/createOrder/${table}`, sending)

      .then((response) => {
        // ////console.log(response + "the order has been created succesfully");
        setShowSpinner(false);
        setsuccessOrder("Success Submit");
        localStorage.clear();
        setTimeout(() => {
          navigate("/");
        }, 1000);
      })
      .catch((error) => {
        if (axios.isAxiosError(error)) {
          // Το error είναι τύπου AxiosError
          if (error.response) {
            console.log(error.response.data);
            showAlert(error.response.data || "Σφάλμα από τον server");
          } else if (error.request) {
            showAlert(
              "Δεν υπάρχει απόκριση από τον server. Ελέγξτε τη σύνδεσή σας."
            );
          } else {
            showAlert("Σφάλμα κατά την αποστολή του αιτήματος.");
          }
        } else {
          showAlert("Άγνωστο σφάλμα.");
        }
      });
  }

  const [idPr, setIdPr] = useState(""); //useState for the specs of product when
  const [pricePr, setPricePr] = useState<number>(0); //push the "+" button
  const [quantityPr, setQuantityPr] = useState(0);
  const [categoryPr, setCategoryPr] = useState("");

  function handlePrepareProduct( //set the values of the product
    id: string,
    price: number,
    quantity: number,
    category: string
  ) {
    setIdPr(id);
    setPricePr(price);
    setQuantityPr(quantity);
    setCategoryPr(category);
  }

  function handleIncreaseProduct(
    id: string,
    price: number,
    quantity: number,
    category: string,
    specifications: string[]
  ) {
    setProductList((prevProducts) => {
      const productExists = prevProducts!.find((product) => product.id === id);
      const specExists = productList.find(
        (product) => product.specifications === (product.specifications as any)
      );

      if (productExists && specExists) {
        return prevProducts!.map((product) =>
          product.id === id && product.specifications == specifications
            ? {
              ...product,

              quantity: product.quantity + 1,
            }
            : product
        );
      }

      return prevProducts;
    });
  }
  function handleDecreaseProduct(
    id: string,
    price: number,
    quantity: number,
    category: string,
    specifications: string[]
  ) {
    ////console.log(id, price, quantity, category, specifications);
    setProductList((prevProducts) => {
      const productExists = prevProducts!.find((product) => product.id === id);
      const specExists = productList.find(
        (product) => product.specifications === (product.specifications as any)
      );
      ////console.log(productExists, specExists);
      if (productExists && specExists) {
        ////console.log("here is the product");
        return prevProducts!
          .map((product) =>
            product.id === id && product.specifications == specifications
              ? {
                ...product,

                quantity: product.quantity - 1,
              }
              : product
          )
          .filter((product) => product.quantity > 0); // Filter out products with quantity 0
      }
      return prevProducts; // In case product does not exist, return previous products
    });
  }
  function handleDeleteProduct(
    id: string,
    price: number,
    quantity: number,
    category: string,
    specifications: string[]
  ) {
    ////console.log(id, price, quantity, category, specifications);
    setProductList((prevProducts) => {
      const productExists = prevProducts!.find((product) => product.id === id);
      const specExists = productList.find(
        (product) => product.specifications === (product.specifications as any)
      );
      ////console.log(productExists, specExists);
      if (productExists && specExists) {
        ////console.log("here is the product");
        return prevProducts!
          .map((product) =>
            product.id === id && product.specifications == specifications
              ? {
                ...product,

                quantity: 0,
              }
              : product
          )
          .filter((product) => product.quantity > 0); // Filter out products with quantity 0
      }
      return prevProducts; // In case product does not exist, return previous products
    });
  }
  function handleOrderIncrease(event: FormEvent<HTMLFormElement>) {
    //submit checkbox
    ////console.log("here we are");
    event.preventDefault();
    setShowModalCategory(false);
    const Values: string[] = [];
    Object.entries(selectedValues).forEach(([key, values]) => {
      const keys = Object.keys(categoryOptions);
      values.forEach((value, index) => {
        if (value === true) {
          for (let k = 0; k < keys.length; k++) {
            if (key === keys[k]) {
              ////console.log(keys[k] + "fu");
              ////console.log(
              // (categoryOptions as any)[keys[k]][index],
              // "the l is here"
              //  );
              Values.push((categoryOptions as any)[keys[k]][index]);
            }
          }
        }
        setSelectedValues(
          Object.fromEntries(
            Object.entries(categoryOptions).map(([key, values]) => [
              key,
              values.map(() => false),
            ])
          )
        );
      });
    });
    setProductList((prevProducts) => {
      let productUpdated = false;

      const updatedProducts = prevProducts!.map((product) => {
        ////console.log(prevProducts, "every time");
        ////console.log(Values, product.specifications);

        const productName = product.id === idPr;
        const productValues =
          JSON.stringify(product.specifications) === JSON.stringify(Values);

        if (productName && productValues) {
          productUpdated = true;
          return {
            ...product,
            quantity: product.quantity + 1,
          };
        }

        return product;
      });
      let extra_value = 0;
      //console.log(selectedValues + "here is the selected value");
      Object.entries(selectedValues).forEach(([category, selectedArray]) => {
        selectedArray.forEach((isSelected, index) => {
          //console.log(
          // (categoryOptions[category][index] as any) + "here is before crash"
          //  );

          if (isSelected) {
            //console.log(
            //   "here is the if selected" + extraCosts[category][index]
            //   );
            extra_value += parseFloat(extraCosts[category][index] as any);
          }
          //console.log(
          // `Category: ${category}, Item: ${item}, Selected: ${isSelected}`
          // );
        });
      });
      let final_value =
        parseFloat(pricePr as any) + parseFloat(extra_value as any);
      //console.log("pricePr " + pricePr);
      //console.log("extra value " + extra_value);
      //console.log("hello the final price " + final_value);

      if (!productUpdated) {
        const newProduct = {
          id: idPr,
          price: final_value,
          quantity: 1,
          specifications: Values,
          category: categoryPr,
        };
        return [...updatedProducts, newProduct];
      }

      return updatedProducts;
    });
  }
  const [showModalCheckOrder, setShowModalCheckOrder] = useState(false); //starting the confirm order checkbox
  const [showSpinner, setShowSpinner] = useState(false);
  const [successOrder, setsuccessOrder] = useState("Submit");

  function handleCheckOrder() {
    setShowModalCheckOrder(true);
  }
  const renderModalBody = () => {
    //cases for confirm checkbox order(bosy of modal)
    if (successOrder === "Submit") {
      return (
        <>
          <Modal.Header
            closeButton
            onClick={() => setShowModalCheckOrder(false)}
          >
            Θέλετε να καταχωρήσετε την παραγγελία ?
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column ">
            <Button
              onClick={() => {
                setShowSpinner(true);
                sendOrder();
              }}
              type="submit"
              variant="primary"
              className="edit-menu-button border border-dark mt-2 mb-2 bg-secondary text-white"
            >
              {showSpinner ? <i className="fa fa-spinner fa-spin"></i> : "Ναι"}
            </Button>

            <Button
              type="submit"
              variant="primary"
              className={`edit-menu-button border border-dark mt-2 mb-2 ${showSpinner ? "disabled" : ""
                }`}
              onClick={() => setShowModalCheckOrder(false)}
            >
              Όχι
            </Button>
          </Modal.Body>
        </>
      );
    } else if (successOrder === "Success Submit") {
      return (
        <>
          <Modal.Header
            closeButton
            onClick={() => {
              setShowModalCheckOrder(false);
              setsuccessOrder("Submit");
            }}
          >
            H παραγγελια καταχωρήθηκε επιτυχώς
          </Modal.Header>
          <Modal.Body className=" d-flex flex-column justify-content-center align-items-center">
            <div className="circular-icon" style={{ padding: "interhit" }}>
              <i className="fa-solid fa-check fa-3x bg-success rounded rounded-circle"></i>
            </div>
          </Modal.Body>
        </>
      );
    }
  };
  const [showCategories, setShowCategories] = useState(true);
  function handleOrderDecrease() { }
  const [modalShow, setModalShow] = useState(false);
  function handleNavigate() {
    if (productList.length === 0) {
      console.log(productList);
      console.log("δεν έχω προιόντα ");
      window.history.back();
    } else {
      setModalShow(true);
      console.log(productList);
      console.log("'εχω προιοντά");
    }
  }
  if (showCategories) {
    return (
      <>
        <Back_Modal
          isVisible={modalShow}
          text="Θέλετε σίγουρα να πάτε πίσω τα δεδομένα της παρραγελίας θα χαθούν"
          onClose={() => setModalShow(false)}
        ></Back_Modal>
        <div className="row">
          <div className="col-12">
            <motion.button
              className="edit-menu-button rounded border mt-2 border-dark bg-white text-dark ms-2 mt-1"
              onClick={() => {
                handleNavigate();
              }}
            >
              <i className="fa-solid fa-arrow-left"></i>
              &nbsp;Back
            </motion.button>
          </div>

          {categoriesList.length > 0 &&
            categoriesList.map((category) => (
              <Category_Icons
                key={category}
                id={category}
                img={{
                  src: `/assets/${category}.jpg`,
                  alt: `${category} Icon`,
                }}
                handleCategory={() => {
                  handleCategory(category);
                  setShowCategories(false);
                }}
              />
            ))}
        </div>
      </>
    );
  } else {
    return (
      <>
        <div className="col-12">
          <motion.button
            className="edit-menu-button rounded border mt-1 ms-1 border-dark bg-white text-dark "
            onClick={() => {
              setShowCategories(true);
            }}
          >
            <i className="fa-solid fa-arrow-left"></i>
            &nbsp;Back
          </motion.button>
          <div className="text-center fw-bold ">Τραπέζι {table}</div>
        </div>
        <div
          className="col-12"
          style={{
            fontSize: "12px",
          }}
        >
          {renderProducts()}
        </div>
        <div className="col-12 p-1">
          <div
            className="order-border mt-6 d-flex flex-column justify-content-between"
            style={{
              fontSize: "12px",
            }}
          >
            <h5>Παραγγελία</h5>

            <ul className="order-list list-unstyled p-0 m-0">
              {productList.map((product) => (
                <li className="ps-1 pe-1" key={counterKeys + 1}>
                  <OrderProducts
                    id={product.id}
                    quantity={product.quantity}
                    price={product.price}
                    category={product.category}
                    specifications={product.specifications}
                    onclickIdIncrease={handleIncreaseProduct}
                    onclickIdDecrease={handleDecreaseProduct}
                    onclickIdDelete={handleDeleteProduct}
                  />
                </li>
              ))}
            </ul>
            <Modal
              className="modal-header no-gutters"
              show={showModalCategory}
              onHide={() => setShowModalCategory(false)}
              animation={false}
            >
              <Modal.Header
                className="text-center d-flex flex-column-reverse"
                closeButton
                style={{ background: "orange", color: "white" }}
              >
                {idPr}
              </Modal.Header>
              <Modal.Body style={{ padding: "0" }}>
                <Form onSubmit={handleOrderIncrease}>
                  {Object.entries(categoryOptions).map(([key, values]) => (
                    <div
                      style={{ lineHeight: "0.9em" }}
                      className="w-100"
                      key={key}
                    >
                      <h6 className="text-left text-capitalize ps-1 border-dark border-bottom border-top">
                        {key}
                      </h6>
                      <div className="row no-gutters ps-1 pe-1 text-left align-items-center">
                        {values.map((value, index) => (
                          <div
                            className="col-4 mt-1 mb-1 d-flex "
                            key={value as any}
                          >
                            <input
                              type="checkbox"
                              id={`${key}-${value}`}
                              onChange={() =>
                                handleCheckboxChange(value as any, key, index)
                              }
                              value={value as any}
                            />
                            <label className="ps-1" htmlFor={`${key}-${value}`}>
                              <div style={{ fontSize: "16px" }}>
                                {value as any}
                              </div>
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                  <Button
                    style={{ display: "block" }}
                    type="submit"
                    variant="primary"
                    className="edit-menu-button mb-2 mt-2 border border-dark bg-secondary text-white m-auto"
                  >
                    Add Product
                  </Button>
                </Form>
              </Modal.Body>
            </Modal>
            <Modal
              className="modal-header no-gutters d-flex justify-content-center align-items-center"
              show={showModalCheckOrder}
              onHide={() => setShowModalCheckOrder(false)}
              animation={false}
            >
              {renderModalBody()}
            </Modal>
            <div className="d-flex justify-content-center">
              <Button
                variant="primary"
                onClick={handleCheckOrder}
                className={`order-menu-button edit-menu-button border border-dark mr-3 mt-2 mb-2 bg-secondary text-white ${productList.length === 0 ? "disabled" : ""
                  }`}
              >
                Send Order
              </Button>
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default Catalog;
