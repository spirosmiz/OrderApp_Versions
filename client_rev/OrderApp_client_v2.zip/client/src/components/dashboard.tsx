import { useNavigate, useParams } from "react-router-dom";
import { Accordion, Button, Card } from "react-bootstrap";
import { useEffect, useState } from "react";
import "../index.css";
const localhost = import.meta.env.VITE_API_URL || "http://10.10.10.10";
import "../css/dashboard.css";
import Dash_Modal from "./Modals/dashboard_modal";
import { color } from "framer-motion";
import { BarChart } from "@mui/x-charts";
function DashBoard() {
  const [showModal, setShowModal] = useState(false); //set if modal-visibbility
  const [modalText, setModalText] = useState<string>(); //set the text of modal
  const [modalEndPoint, setModalEndPoint] = useState<string>(); //set the endpoint of modal
  function handleModal(text: string, endpoint: string) {
    //method to change the modal properties
    setModalText(text);
    setModalEndPoint(endpoint);
    setShowModal(true);
  }
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    // Cleanup the timer on component unmount
    return () => clearInterval(timer);
  }, []);
  return (
    <>
      <Dash_Modal
        isVisible={showModal}
        onClose={() => setShowModal(false)}
        text={modalText as string}
        endpoint={modalEndPoint as string}
      ></Dash_Modal>
      <div className="row bg-main dash-height">
        <div className="col-2 bg-dark text-white d-flex flex-column pe-0">
          <div className="border-bottom border-white ps-2">Edit Menu</div>
          <ul className="list-unstyled w-100 mt-3 vastack gap-5 ">
            <li className="li-class mt-2">
              <i className="fa-solid fa-user px-2"></i>
              <span className="li-class">Edit Menu</span>
            </li>
            <li className="li-class mt-2">
              <Accordion className="accordion-class text-white">
                <Accordion.Item
                  eventKey="0"
                  className="accordion-class text-left"
                >
                  <Accordion.Header className="accordion-class text-white">
                    <i className="fa-solid fa-user px-2"></i>
                    <span className="li-class ">Users</span>
                  </Accordion.Header>
                  <Accordion.Body className="text-white">
                    Edit User
                  </Accordion.Body>
                  <Accordion.Body className="text-white">
                    Edit User
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion>
            </li>
            <li className="li-class">
              <Accordion className="accordion-class text-white">
                <Accordion.Item
                  eventKey="0"
                  className="accordion-class text-left"
                >
                  <Accordion.Header className="accordion-class text-white">
                    <i className="fa-solid fa-user px-2"></i>
                    <span className="li-class">Menu</span>
                  </Accordion.Header>
                  <Accordion.Body className="text-white">
                    Edit Products
                  </Accordion.Body>
                  <Accordion.Body className="text-white">
                    Edit Categories
                  </Accordion.Body>
                </Accordion.Item>
              </Accordion>
            </li>
            <li className="li-class mt-2">
              <i className="fa-solid fa-user px-2"></i>
              <span
                onClick={() =>
                  handleModal(
                    "Θέλετε να πραγματοποιήσετε κλείσιμο ημέρας",
                    "closeDay"
                  )
                }
              >
                Close Day
              </span>
            </li>
          </ul>
        </div>
        <div className="col-10 text-white d-flex flex-column ">
          <div className="row p-2 h-100">
            <div className="col-md-7 col-12 mt-1 mt-md-0">
              <Card className="text-white bg-card" style={{ height: "250px" }}>
                <Card.Title className="border-white border-bottom p-1 ">
                  Statistics
                </Card.Title>
                <Card.Body className="p-1 d-flex">
                  <BarChart
                    series={[
                      { data: [870, 440, 240, 349] },
                      { data: [700, 600, 49, 30] },
                      { data: [500, 180, 300, 150] },
                      { data: [1000, 340, 185, 259] },
                    ]}
                    height={180}
                    xAxis={[
                      { data: ["Q1", "Q2", "Q3", "Q4"], scaleType: "band" },
                    ]}
                    margin={{ top: 10, bottom: 30, left: 40, right: 10 }}
                  />
                </Card.Body>
              </Card>
            </div>
            <div className="col-md-5 col-12 mt-1 mt-md-0">
              <Card className="text-white bg-card" style={{ height: "250px" }}>
                <Card.Body className="p-0">
                  <Card.Title className="border-white border-bottom p-1 ">
                    Users Stats
                  </Card.Title>
                </Card.Body>
              </Card>
            </div>
            <div className="col-md-4 col-12 mt-md-3 mt-1">
              <Card className="text-white bg-card" style={{ height: "250px" }}>
                <Card.Title className="border-white border-bottom p-1 ">
                  Today
                </Card.Title>
                <Card.Body className="p-1">
                  <div className="row font-big">
                    <div className="col-12">
                      <p>{currentTime.toLocaleString()}</p>
                    </div>
                    <div className="col-12">
                      <div>Today's Income</div>
                      <div>400.50 €</div>
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </div>
            <div className="col-md-5 col-12 mt-md-3 mt-1">
              <Card className="text-white bg-card" style={{ height: "250px" }}>
                <Card.Title className="border-white border-bottom p-1 ">
                  Top Products
                </Card.Title>
                <Card.Body className="p-1">
                  <div className="row font-big">
                    <div className="col-8">
                      <div>Freddo Espreesso</div>
                      <div>Freddo Espreesso</div>
                      <div>Freddo Espreesso</div>
                      <div>Freddo Espreesso</div>
                      <div>Freddo Espreesso</div>
                    </div>
                    <div className="col-4">
                      <div>20</div>
                      <div>23</div>
                      <div>23</div>
                      <div>23</div>
                      <div>23</div>
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </div>
            <div className="col-md-3 col-12 mt-md-3 mt-1">
              <Card className="text-white bg-card" style={{ height: "250px" }}>
                <Card.Title className="border-white border-bottom p-1 ">
                  Contact us
                </Card.Title>
                <Card.Body className="p-0">
                  <div className="row p-1">
                    <div className="col-3">Tel.</div>
                    <div className="col-9">+30 698 5764 950</div>
                    <div className="col-3 text-center"></div>
                    <div className="col-9">+30 695 1956 643 </div>
                  </div>
                  <div className="row p-1">
                    <div className="col-3">Email</div>
                    <div className="col-9">aris.zerbinis@gmail.com</div>
                    <div className="col-3"></div>
                    <div className="col-9">spiros.miz@gmail.com</div>
                  </div>
                  <div className="row p-1">
                    <div className="col-3">Social</div>
                    <div className="col-9">
                      <i
                        className="fab fa-instagram"
                        style={{ fontSize: "20px", color: "lightgreen" }}
                      ></i>
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </div>
            <div className="col-md-8 col-12 mt-md-3 mt-1">
              <Card className="text-white bg-card" style={{ height: "250px" }}>
                <Card.Body className="p-0">
                  <Card.Title className="border-white border-bottom p-1 ">
                    Statistics
                  </Card.Title>
                </Card.Body>
              </Card>
            </div>
            <div className="col-md-4 col-12 mt-1 mt-md-3">
              <Card className="text-white bg-card" style={{ height: "250px" }}>
                <Card.Body className="p-0">
                  <Card.Title className="border-white border-bottom p-1 ">
                    Statistics
                  </Card.Title>
                </Card.Body>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default DashBoard;
