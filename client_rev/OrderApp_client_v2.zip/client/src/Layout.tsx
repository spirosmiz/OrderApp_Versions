// Layout.tsx
import React from "react";
import { Outlet } from "react-router-dom";
import Header from "./components/header";
import "./index.css";
import "./sass/bootstrap.scss";
import "./sass/font-awesome.scss";

const Layout: React.FC = () => {
  return (
    <div>
      <Header /> {/* Always visible Header */}
      <Outlet /> {/* Renders the routed components */}
    </div>
  );
};

export default Layout;
