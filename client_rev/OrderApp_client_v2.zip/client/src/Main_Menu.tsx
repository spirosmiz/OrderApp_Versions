import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./index.css";
import "./sass/bootstrap.scss";
import "./sass/font-awesome.scss";
import Card from "react-bootstrap/Card";
import { motion } from "framer-motion";

function MainMenu() {
  const [selectedId, setSelectedId] = useState("");
  const navigate = useNavigate();
  const items = [{ position: "Παιδική Χαρά" }, { position: "Κάτω" }];

  function handleItemClick(position: string) {
    setSelectedId(position);
    navigate(`/app/${position}`);
  }

  return (
    <>
      {items.map((item) => (
        <motion.div
          className="p-1"
          key={item.position}
          layoutId={item.position}
          onClick={() => handleItemClick(item.position)}
        >
          <Card className="mt-3 text-center p-5">{item.position}</Card>
        </motion.div>
      ))}
    </>
  );
}

export default MainMenu;
