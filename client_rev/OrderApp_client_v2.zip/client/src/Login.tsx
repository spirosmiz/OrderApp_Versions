import { FormEvent, useRef } from "react";
import "./css/Login.css";
import "./sass/bootstrap.scss";
import "./sass/font-awesome.scss";
import "@fontsource/playfair-display";
import { Button, Form } from "react-bootstrap";

type UserSpecs = {
  username: string;
  password: string;
};
function Login<User extends UserSpecs>() {
  const username = useRef<HTMLInputElement>(null);
  const password = useRef<HTMLInputElement>(null);

  function submitUser(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (username.current && password.current) {
      const userData = {
        username: username.current.value,
        password: password.current.value,
      } as User;
      console.log(userData);
    }
  }
  return (
    <div className="container-fluid h-100">
      <div
        className="row text-center justify-content-center"
        style={{ fontSize: "25px", fontFamily: "'Playfair Display', serif" }}
      >
        <div className="col-12 d-flex justify-content-center align-items-center">
          Order App
        </div>
        <div
          className="col-8 col-sm-6 col-md-4 rounded-3 d-flex flex-column justify-content-center border border-dark mt-5 bg-main"
          style={{
            backgroundColor: "lightgray",
            boxShadow: "0 4px 8px rgba(0, 0, 0, 0.8)",
          }}
        >
          <div>Login</div>
          <Form
            autoComplete="off"
            className="mt-4 text-center h-100"
            onSubmit={submitUser}
          >
            <Form.Group
              style={{ fontSize: "15px" }}
              className="d-flex flex-column align-items-center"
              controlId="formUser"
            >
              <Form.Label className="mt-3" style={{ fontSize: "15px" }}>
                Username
              </Form.Label>
              <input
                className="input-class w-75"
                type="text"
                placeholder="Username"
                ref={username}
                autoComplete="off"
                required
              />
            </Form.Group>

            <Form.Group
              style={{ fontSize: "15px" }}
              className="d-flex flex-column align-items-center pb-2"
            >
              <Form.Label className="mt-3" style={{ fontSize: "15px" }}>
                Password
              </Form.Label>
              <input
                id="password"
                accept=""
                style={{ border: "none" }}
                className="input-class w-75"
                type="password"
                placeholder="Password"
                ref={password}
                autoComplete="off"
                required
              />
              <a
                className="d-flex justify-content-end mt-2 mb-2 w-75"
                style={{ color: "purple", fontSize: "13px" }}
              >
                <span className="anchor_tag">Forgot Password</span>
              </a>
              <Button
                type="submit"
                className="d-flex justify-content-center edit-menu-button border border-dark mt-5 mb-2 bg-secondary text-white w-75"
              >
                Login
              </Button>
            </Form.Group>
          </Form>
        </div>
      </div>
    </div>
  );
}

export default Login;
