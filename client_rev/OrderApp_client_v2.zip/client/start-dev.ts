import { exec } from "child_process";
// Enable ES module loading
// Use exec as needed
exec("npm run dev", (error: any, stdout: any, stderr: any) => {
  if (error) {
    console.error(`exec error: ${error}`);
    return;
  }
  console.log(`stdout: ${stdout}`);
  console.error(`stderr: ${stderr}`);
});
